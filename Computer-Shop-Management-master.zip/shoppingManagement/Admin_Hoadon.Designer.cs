﻿
namespace shoppingManagement
{
    partial class Admin_Hoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Hoadon));
            this.txttongtien = new JMaterialTextbox.JMaterialTextbox();
            this.txtconlai = new JMaterialTextbox.JMaterialTextbox();
            this.label16 = new System.Windows.Forms.Label();
            this.txttienkm = new JMaterialTextbox.JMaterialTextbox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dLap = new JMaterialTextbox.JMaterialTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.timkiem = new ePOSOne.btnProduct.Button_WOC();
            this.TraCuu = new JMaterialTextbox.JMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.LoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtghichu = new JMaterialTextbox.JMaterialTextbox();
            this.txtslsp = new JMaterialTextbox.JMaterialTextbox();
            this.txtmakm = new JMaterialTextbox.JMaterialTextbox();
            this.txtmahd = new JMaterialTextbox.JMaterialTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.lammoi = new ePOSOne.btnProduct.Button_WOC();
            this.capnhat = new ePOSOne.btnProduct.Button_WOC();
            this.xoa = new ePOSOne.btnProduct.Button_WOC();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtmanv = new JMaterialTextbox.JMaterialTextbox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtmakh = new JMaterialTextbox.JMaterialTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // txttongtien
            // 
            this.txttongtien.BackColor = System.Drawing.Color.Transparent;
            this.txttongtien.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttongtien.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttongtien.ForeColors = System.Drawing.Color.Black;
            this.txttongtien.HintText = null;
            this.txttongtien.IsPassword = false;
            this.txttongtien.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txttongtien.LineThickness = 2;
            this.txttongtien.Location = new System.Drawing.Point(129, 216);
            this.txttongtien.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttongtien.MaxLength = 32767;
            this.txttongtien.Name = "txttongtien";
            this.txttongtien.OnFocusedColor = System.Drawing.Color.Black;
            this.txttongtien.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txttongtien.ReadOnly = false;
            this.txttongtien.Size = new System.Drawing.Size(161, 23);
            this.txttongtien.TabIndex = 146;
            this.txttongtien.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txttongtien.TextName = "";
            // 
            // txtconlai
            // 
            this.txtconlai.BackColor = System.Drawing.Color.Transparent;
            this.txtconlai.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtconlai.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtconlai.ForeColors = System.Drawing.Color.Black;
            this.txtconlai.HintText = null;
            this.txtconlai.IsPassword = false;
            this.txtconlai.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtconlai.LineThickness = 2;
            this.txtconlai.Location = new System.Drawing.Point(404, 277);
            this.txtconlai.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtconlai.MaxLength = 32767;
            this.txtconlai.Name = "txtconlai";
            this.txtconlai.OnFocusedColor = System.Drawing.Color.Black;
            this.txtconlai.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtconlai.ReadOnly = false;
            this.txtconlai.Size = new System.Drawing.Size(250, 18);
            this.txtconlai.TabIndex = 145;
            this.txtconlai.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtconlai.TextName = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(331, 277);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 19);
            this.label16.TabIndex = 144;
            this.label16.Text = "Còn lại:";
            // 
            // txttienkm
            // 
            this.txttienkm.BackColor = System.Drawing.Color.Transparent;
            this.txttienkm.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttienkm.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttienkm.ForeColors = System.Drawing.Color.Black;
            this.txttienkm.HintText = null;
            this.txttienkm.IsPassword = false;
            this.txttienkm.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txttienkm.LineThickness = 2;
            this.txttienkm.Location = new System.Drawing.Point(129, 277);
            this.txttienkm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttienkm.MaxLength = 32767;
            this.txttienkm.Name = "txttienkm";
            this.txttienkm.OnFocusedColor = System.Drawing.Color.Black;
            this.txttienkm.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txttienkm.ReadOnly = false;
            this.txttienkm.Size = new System.Drawing.Size(161, 18);
            this.txttienkm.TabIndex = 143;
            this.txttienkm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txttienkm.TextName = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(20, 277);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 19);
            this.label15.TabIndex = 142;
            this.label15.Text = "Khuyến mãi:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(20, 220);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 19);
            this.label14.TabIndex = 140;
            this.label14.Text = "Tổng tiền:";
            // 
            // dLap
            // 
            this.dLap.BackColor = System.Drawing.Color.Transparent;
            this.dLap.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dLap.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dLap.ForeColors = System.Drawing.Color.Black;
            this.dLap.HintText = null;
            this.dLap.IsPassword = false;
            this.dLap.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dLap.LineThickness = 2;
            this.dLap.Location = new System.Drawing.Point(145, 163);
            this.dLap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dLap.MaxLength = 32767;
            this.dLap.Name = "dLap";
            this.dLap.OnFocusedColor = System.Drawing.Color.Black;
            this.dLap.OnFocusedTextColor = System.Drawing.Color.Black;
            this.dLap.ReadOnly = false;
            this.dLap.Size = new System.Drawing.Size(145, 23);
            this.dLap.TabIndex = 139;
            this.dLap.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dLap.TextName = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 19);
            this.label2.TabIndex = 138;
            this.label2.Text = "Thời gian lập:";
            // 
            // timkiem
            // 
            this.timkiem.BackColor = System.Drawing.Color.White;
            this.timkiem.BorderColor = System.Drawing.Color.Black;
            this.timkiem.ButtonColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderSize = 0;
            this.timkiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timkiem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timkiem.Location = new System.Drawing.Point(790, 29);
            this.timkiem.Name = "timkiem";
            this.timkiem.OnHoverBorderColor = System.Drawing.Color.Black;
            this.timkiem.OnHoverButtonColor = System.Drawing.Color.White;
            this.timkiem.OnHoverTextColor = System.Drawing.Color.Black;
            this.timkiem.Size = new System.Drawing.Size(58, 38);
            this.timkiem.TabIndex = 137;
            this.timkiem.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.UseVisualStyleBackColor = false;
            this.timkiem.Click += new System.EventHandler(this.timkiem_Click);
            // 
            // TraCuu
            // 
            this.TraCuu.BackColor = System.Drawing.Color.Transparent;
            this.TraCuu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.ForeColors = System.Drawing.Color.Black;
            this.TraCuu.HintText = null;
            this.TraCuu.IsPassword = false;
            this.TraCuu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TraCuu.LineThickness = 2;
            this.TraCuu.Location = new System.Drawing.Point(511, 31);
            this.TraCuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TraCuu.MaxLength = 32767;
            this.TraCuu.Name = "TraCuu";
            this.TraCuu.OnFocusedColor = System.Drawing.Color.Black;
            this.TraCuu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TraCuu.ReadOnly = false;
            this.TraCuu.Size = new System.Drawing.Size(255, 23);
            this.TraCuu.TabIndex = 136;
            this.TraCuu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TraCuu.TextName = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(384, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 19);
            this.label11.TabIndex = 135;
            this.label11.Text = "Nhập từ khóa:";
            // 
            // LoaiTimKiem
            // 
            this.LoaiTimKiem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaiTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaiTimKiem.FormattingEnabled = true;
            this.LoaiTimKiem.Items.AddRange(new object[] {
            "MaHD",
            "MaNV",
            "MaKH"});
            this.LoaiTimKiem.Location = new System.Drawing.Point(282, 31);
            this.LoaiTimKiem.Name = "LoaiTimKiem";
            this.LoaiTimKiem.Size = new System.Drawing.Size(92, 21);
            this.LoaiTimKiem.TabIndex = 134;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(155, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 19);
            this.label6.TabIndex = 133;
            this.label6.Text = "Tìm kiếm theo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 336);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(165, 19);
            this.label5.TabIndex = 132;
            this.label5.Text = "Danh sách hóa đơn:";
            // 
            // txtghichu
            // 
            this.txtghichu.BackColor = System.Drawing.Color.Transparent;
            this.txtghichu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtghichu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtghichu.ForeColors = System.Drawing.Color.Black;
            this.txtghichu.HintText = null;
            this.txtghichu.IsPassword = false;
            this.txtghichu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtghichu.LineThickness = 2;
            this.txtghichu.Location = new System.Drawing.Point(412, 221);
            this.txtghichu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtghichu.MaxLength = 32767;
            this.txtghichu.Name = "txtghichu";
            this.txtghichu.OnFocusedColor = System.Drawing.Color.Black;
            this.txtghichu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtghichu.ReadOnly = false;
            this.txtghichu.Size = new System.Drawing.Size(242, 18);
            this.txtghichu.TabIndex = 131;
            this.txtghichu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtghichu.TextName = "";
            // 
            // txtslsp
            // 
            this.txtslsp.BackColor = System.Drawing.Color.Transparent;
            this.txtslsp.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtslsp.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtslsp.ForeColors = System.Drawing.Color.Black;
            this.txtslsp.HintText = null;
            this.txtslsp.IsPassword = false;
            this.txtslsp.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtslsp.LineThickness = 2;
            this.txtslsp.Location = new System.Drawing.Point(504, 168);
            this.txtslsp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtslsp.MaxLength = 32767;
            this.txtslsp.Name = "txtslsp";
            this.txtslsp.OnFocusedColor = System.Drawing.Color.Black;
            this.txtslsp.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtslsp.ReadOnly = false;
            this.txtslsp.Size = new System.Drawing.Size(150, 18);
            this.txtslsp.TabIndex = 130;
            this.txtslsp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtslsp.TextName = "";
            // 
            // txtmakm
            // 
            this.txtmakm.BackColor = System.Drawing.Color.Transparent;
            this.txtmakm.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmakm.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmakm.ForeColors = System.Drawing.Color.Black;
            this.txtmakm.HintText = null;
            this.txtmakm.IsPassword = false;
            this.txtmakm.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtmakm.LineThickness = 2;
            this.txtmakm.Location = new System.Drawing.Point(384, 109);
            this.txtmakm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmakm.MaxLength = 32767;
            this.txtmakm.Name = "txtmakm";
            this.txtmakm.OnFocusedColor = System.Drawing.Color.Black;
            this.txtmakm.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtmakm.ReadOnly = false;
            this.txtmakm.Size = new System.Drawing.Size(82, 18);
            this.txtmakm.TabIndex = 129;
            this.txtmakm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtmakm.TextName = "";
            // 
            // txtmahd
            // 
            this.txtmahd.BackColor = System.Drawing.Color.Transparent;
            this.txtmahd.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmahd.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmahd.ForeColors = System.Drawing.Color.Black;
            this.txtmahd.HintText = null;
            this.txtmahd.IsPassword = false;
            this.txtmahd.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtmahd.LineThickness = 2;
            this.txtmahd.Location = new System.Drawing.Point(149, 104);
            this.txtmahd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmahd.MaxLength = 32767;
            this.txtmahd.Name = "txtmahd";
            this.txtmahd.OnFocusedColor = System.Drawing.Color.Black;
            this.txtmahd.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtmahd.ReadOnly = false;
            this.txtmahd.Size = new System.Drawing.Size(82, 23);
            this.txtmahd.TabIndex = 128;
            this.txtmahd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtmahd.TextName = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 19);
            this.label1.TabIndex = 127;
            this.label1.Text = "Mã khuyến mãi:";
            // 
            // lammoi
            // 
            this.lammoi.BorderColor = System.Drawing.Color.Black;
            this.lammoi.ButtonColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderSize = 0;
            this.lammoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.lammoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lammoi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lammoi.Location = new System.Drawing.Point(869, 29);
            this.lammoi.Name = "lammoi";
            this.lammoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverButtonColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverTextColor = System.Drawing.Color.White;
            this.lammoi.Size = new System.Drawing.Size(58, 38);
            this.lammoi.TabIndex = 126;
            this.lammoi.TextColor = System.Drawing.Color.Black;
            this.lammoi.UseVisualStyleBackColor = true;
            this.lammoi.Click += new System.EventHandler(this.lammoi_Click);
            // 
            // capnhat
            // 
            this.capnhat.BorderColor = System.Drawing.Color.Black;
            this.capnhat.ButtonColor = System.Drawing.Color.White;
            this.capnhat.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.capnhat.FlatAppearance.BorderSize = 0;
            this.capnhat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.capnhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.capnhat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capnhat.Location = new System.Drawing.Point(523, 318);
            this.capnhat.Name = "capnhat";
            this.capnhat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.capnhat.OnHoverButtonColor = System.Drawing.Color.White;
            this.capnhat.OnHoverTextColor = System.Drawing.Color.Black;
            this.capnhat.Size = new System.Drawing.Size(58, 38);
            this.capnhat.TabIndex = 125;
            this.capnhat.TextColor = System.Drawing.Color.White;
            this.capnhat.UseVisualStyleBackColor = true;
            this.capnhat.Click += new System.EventHandler(this.capnhat_Click);
            // 
            // xoa
            // 
            this.xoa.BorderColor = System.Drawing.Color.Black;
            this.xoa.ButtonColor = System.Drawing.Color.White;
            this.xoa.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.xoa.FlatAppearance.BorderSize = 0;
            this.xoa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.xoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xoa.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xoa.Location = new System.Drawing.Point(612, 317);
            this.xoa.Name = "xoa";
            this.xoa.OnHoverBorderColor = System.Drawing.Color.Black;
            this.xoa.OnHoverButtonColor = System.Drawing.Color.White;
            this.xoa.OnHoverTextColor = System.Drawing.Color.Black;
            this.xoa.Size = new System.Drawing.Size(58, 38);
            this.xoa.TabIndex = 124;
            this.xoa.TextColor = System.Drawing.Color.White;
            this.xoa.UseVisualStyleBackColor = true;
            this.xoa.Click += new System.EventHandler(this.xoa_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(331, 220);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 121;
            this.label9.Text = "Ghi chú:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(331, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 19);
            this.label8.TabIndex = 120;
            this.label8.Text = "Số lượng sản phẩm:";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(17, 20);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 119;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 19);
            this.label3.TabIndex = 118;
            this.label3.Text = "Mã hóa đơn:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, 368);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(988, 238);
            this.dataGridView1.TabIndex = 117;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // txtmanv
            // 
            this.txtmanv.BackColor = System.Drawing.Color.Transparent;
            this.txtmanv.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmanv.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmanv.ForeColors = System.Drawing.Color.Black;
            this.txtmanv.HintText = null;
            this.txtmanv.IsPassword = false;
            this.txtmanv.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtmanv.LineThickness = 2;
            this.txtmanv.Location = new System.Drawing.Point(615, 109);
            this.txtmanv.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmanv.MaxLength = 32767;
            this.txtmanv.Name = "txtmanv";
            this.txtmanv.OnFocusedColor = System.Drawing.Color.Black;
            this.txtmanv.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtmanv.ReadOnly = false;
            this.txtmanv.Size = new System.Drawing.Size(82, 18);
            this.txtmanv.TabIndex = 148;
            this.txtmanv.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtmanv.TextName = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(486, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 19);
            this.label4.TabIndex = 147;
            this.label4.Text = "Mã nhân viên:";
            // 
            // txtmakh
            // 
            this.txtmakh.BackColor = System.Drawing.Color.Transparent;
            this.txtmakh.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmakh.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtmakh.ForeColors = System.Drawing.Color.Black;
            this.txtmakh.HintText = null;
            this.txtmakh.IsPassword = false;
            this.txtmakh.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtmakh.LineThickness = 2;
            this.txtmakh.Location = new System.Drawing.Point(862, 109);
            this.txtmakh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtmakh.MaxLength = 32767;
            this.txtmakh.Name = "txtmakh";
            this.txtmakh.OnFocusedColor = System.Drawing.Color.Black;
            this.txtmakh.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtmakh.ReadOnly = false;
            this.txtmakh.Size = new System.Drawing.Size(82, 18);
            this.txtmakh.TabIndex = 150;
            this.txtmakh.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtmakh.TextName = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(726, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 19);
            this.label7.TabIndex = 149;
            this.label7.Text = "Mã khách hàng:";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(886, 37);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 155;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(542, 326);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(23, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 154;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(631, 326);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(23, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 153;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(809, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 151;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(704, 134);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(310, 228);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 156;
            this.pictureBox5.TabStop = false;
            // 
            // Admin_Hoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtmakh);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtmanv);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txttongtien);
            this.Controls.Add(this.txtconlai);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txttienkm);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dLap);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.timkiem);
            this.Controls.Add(this.TraCuu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LoaiTimKiem);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtghichu);
            this.Controls.Add(this.txtslsp);
            this.Controls.Add(this.txtmakm);
            this.Controls.Add(this.txtmahd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lammoi);
            this.Controls.Add(this.capnhat);
            this.Controls.Add(this.xoa);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Admin_Hoadon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Hóa Đơn";
            this.Load += new System.EventHandler(this.Admin_Hoadon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JMaterialTextbox.JMaterialTextbox txttongtien;
        private JMaterialTextbox.JMaterialTextbox txtconlai;
        private System.Windows.Forms.Label label16;
        private JMaterialTextbox.JMaterialTextbox txttienkm;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private JMaterialTextbox.JMaterialTextbox dLap;
        private System.Windows.Forms.Label label2;
        private ePOSOne.btnProduct.Button_WOC timkiem;
        private JMaterialTextbox.JMaterialTextbox TraCuu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox LoaiTimKiem;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private JMaterialTextbox.JMaterialTextbox txtghichu;
        private JMaterialTextbox.JMaterialTextbox txtslsp;
        private JMaterialTextbox.JMaterialTextbox txtmakm;
        private JMaterialTextbox.JMaterialTextbox txtmahd;
        private System.Windows.Forms.Label label1;
        private ePOSOne.btnProduct.Button_WOC lammoi;
        private ePOSOne.btnProduct.Button_WOC capnhat;
        private ePOSOne.btnProduct.Button_WOC xoa;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private JMaterialTextbox.JMaterialTextbox txtmanv;
        private System.Windows.Forms.Label label4;
        private JMaterialTextbox.JMaterialTextbox txtmakh;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}