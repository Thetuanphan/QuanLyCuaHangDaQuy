﻿namespace shoppingManagement
{
    partial class Admin_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.qlphieudv = new ePOSOne.btnProduct.Button_WOC();
            this.tkdoanhthu = new ePOSOne.btnProduct.Button_WOC();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.qlkhachhang = new ePOSOne.btnProduct.Button_WOC();
            this.qlnhaphang = new ePOSOne.btnProduct.Button_WOC();
            this.qldichvu = new ePOSOne.btnProduct.Button_WOC();
            this.qlhoadon = new ePOSOne.btnProduct.Button_WOC();
            this.qlvatlieu = new ePOSOne.btnProduct.Button_WOC();
            this.qlkhuyenmai = new ePOSOne.btnProduct.Button_WOC();
            this.qldoitac = new ePOSOne.btnProduct.Button_WOC();
            this.qlnhanvien = new ePOSOne.btnProduct.Button_WOC();
            this.qlsanpham = new ePOSOne.btnProduct.Button_WOC();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(242, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(394, 56);
            this.label1.TabIndex = 19;
            this.label1.Text = "MENU QUẢN LÝ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(260, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(337, 31);
            this.label4.TabIndex = 29;
            this.label4.Text = "Chọn Chức Năng Quản Lý";
            // 
            // qlphieudv
            // 
            this.qlphieudv.BorderColor = System.Drawing.Color.Black;
            this.qlphieudv.ButtonColor = System.Drawing.Color.White;
            this.qlphieudv.FlatAppearance.BorderSize = 0;
            this.qlphieudv.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlphieudv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlphieudv.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlphieudv.Location = new System.Drawing.Point(593, 363);
            this.qlphieudv.Name = "qlphieudv";
            this.qlphieudv.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlphieudv.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlphieudv.OnHoverTextColor = System.Drawing.Color.White;
            this.qlphieudv.Size = new System.Drawing.Size(229, 38);
            this.qlphieudv.TabIndex = 35;
            this.qlphieudv.Text = "Quản Lý Phiếu Dịch Vụ";
            this.qlphieudv.TextColor = System.Drawing.Color.Black;
            this.qlphieudv.UseVisualStyleBackColor = true;
            this.qlphieudv.Click += new System.EventHandler(this.qlphieudv_Click);
            // 
            // tkdoanhthu
            // 
            this.tkdoanhthu.BorderColor = System.Drawing.Color.Black;
            this.tkdoanhthu.ButtonColor = System.Drawing.Color.White;
            this.tkdoanhthu.FlatAppearance.BorderSize = 0;
            this.tkdoanhthu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.tkdoanhthu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tkdoanhthu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tkdoanhthu.Location = new System.Drawing.Point(37, 363);
            this.tkdoanhthu.Name = "tkdoanhthu";
            this.tkdoanhthu.OnHoverBorderColor = System.Drawing.Color.Black;
            this.tkdoanhthu.OnHoverButtonColor = System.Drawing.Color.Black;
            this.tkdoanhthu.OnHoverTextColor = System.Drawing.Color.White;
            this.tkdoanhthu.Size = new System.Drawing.Size(229, 38);
            this.tkdoanhthu.TabIndex = 31;
            this.tkdoanhthu.Text = "Thống Kê Doanh Thu";
            this.tkdoanhthu.TextColor = System.Drawing.Color.Black;
            this.tkdoanhthu.UseVisualStyleBackColor = true;
            this.tkdoanhthu.Click += new System.EventHandler(this.tkdoanhthu_Click);
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(12, 12);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(80, 35);
            this.quayve.TabIndex = 30;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // qlkhachhang
            // 
            this.qlkhachhang.BorderColor = System.Drawing.Color.Black;
            this.qlkhachhang.ButtonColor = System.Drawing.Color.White;
            this.qlkhachhang.FlatAppearance.BorderSize = 0;
            this.qlkhachhang.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlkhachhang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlkhachhang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlkhachhang.Location = new System.Drawing.Point(37, 305);
            this.qlkhachhang.Name = "qlkhachhang";
            this.qlkhachhang.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlkhachhang.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlkhachhang.OnHoverTextColor = System.Drawing.Color.White;
            this.qlkhachhang.Size = new System.Drawing.Size(229, 38);
            this.qlkhachhang.TabIndex = 28;
            this.qlkhachhang.Text = "Quản Lý Khách Hàng";
            this.qlkhachhang.TextColor = System.Drawing.Color.Black;
            this.qlkhachhang.UseVisualStyleBackColor = true;
            this.qlkhachhang.Click += new System.EventHandler(this.qlkhachhang_Click);
            // 
            // qlnhaphang
            // 
            this.qlnhaphang.BorderColor = System.Drawing.Color.Black;
            this.qlnhaphang.ButtonColor = System.Drawing.Color.White;
            this.qlnhaphang.FlatAppearance.BorderSize = 0;
            this.qlnhaphang.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlnhaphang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlnhaphang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlnhaphang.Location = new System.Drawing.Point(593, 251);
            this.qlnhaphang.Name = "qlnhaphang";
            this.qlnhaphang.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlnhaphang.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlnhaphang.OnHoverTextColor = System.Drawing.Color.White;
            this.qlnhaphang.Size = new System.Drawing.Size(229, 38);
            this.qlnhaphang.TabIndex = 27;
            this.qlnhaphang.Text = "Quản Lý Nhập Hàng";
            this.qlnhaphang.TextColor = System.Drawing.Color.Black;
            this.qlnhaphang.UseVisualStyleBackColor = true;
            this.qlnhaphang.Click += new System.EventHandler(this.qlnhaphang_Click);
            // 
            // qldichvu
            // 
            this.qldichvu.BorderColor = System.Drawing.Color.Black;
            this.qldichvu.ButtonColor = System.Drawing.Color.White;
            this.qldichvu.FlatAppearance.BorderSize = 0;
            this.qldichvu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qldichvu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qldichvu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qldichvu.Location = new System.Drawing.Point(317, 251);
            this.qldichvu.Name = "qldichvu";
            this.qldichvu.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qldichvu.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qldichvu.OnHoverTextColor = System.Drawing.Color.White;
            this.qldichvu.Size = new System.Drawing.Size(229, 38);
            this.qldichvu.TabIndex = 26;
            this.qldichvu.Text = "Quản Lý Dịch Vụ";
            this.qldichvu.TextColor = System.Drawing.Color.Black;
            this.qldichvu.UseVisualStyleBackColor = true;
            this.qldichvu.Click += new System.EventHandler(this.qldichvu_Click);
            // 
            // qlhoadon
            // 
            this.qlhoadon.BorderColor = System.Drawing.Color.Black;
            this.qlhoadon.ButtonColor = System.Drawing.Color.White;
            this.qlhoadon.FlatAppearance.BorderSize = 0;
            this.qlhoadon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlhoadon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlhoadon.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlhoadon.Location = new System.Drawing.Point(593, 305);
            this.qlhoadon.Name = "qlhoadon";
            this.qlhoadon.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlhoadon.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlhoadon.OnHoverTextColor = System.Drawing.Color.White;
            this.qlhoadon.Size = new System.Drawing.Size(229, 38);
            this.qlhoadon.TabIndex = 25;
            this.qlhoadon.Text = "Quản Lý Hóa Đơn";
            this.qlhoadon.TextColor = System.Drawing.Color.Black;
            this.qlhoadon.UseVisualStyleBackColor = true;
            this.qlhoadon.Click += new System.EventHandler(this.qlhoadon_Click);
            // 
            // qlvatlieu
            // 
            this.qlvatlieu.BorderColor = System.Drawing.Color.Black;
            this.qlvatlieu.ButtonColor = System.Drawing.Color.White;
            this.qlvatlieu.FlatAppearance.BorderSize = 0;
            this.qlvatlieu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlvatlieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlvatlieu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlvatlieu.Location = new System.Drawing.Point(593, 197);
            this.qlvatlieu.Name = "qlvatlieu";
            this.qlvatlieu.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlvatlieu.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlvatlieu.OnHoverTextColor = System.Drawing.Color.White;
            this.qlvatlieu.Size = new System.Drawing.Size(229, 38);
            this.qlvatlieu.TabIndex = 24;
            this.qlvatlieu.Text = "Quản Lý Nguyên Vật Liệu";
            this.qlvatlieu.TextColor = System.Drawing.Color.Black;
            this.qlvatlieu.UseVisualStyleBackColor = true;
            this.qlvatlieu.Click += new System.EventHandler(this.qlvatlieu_Click);
            // 
            // qlkhuyenmai
            // 
            this.qlkhuyenmai.BorderColor = System.Drawing.Color.Black;
            this.qlkhuyenmai.ButtonColor = System.Drawing.Color.White;
            this.qlkhuyenmai.FlatAppearance.BorderSize = 0;
            this.qlkhuyenmai.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlkhuyenmai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlkhuyenmai.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlkhuyenmai.Location = new System.Drawing.Point(317, 305);
            this.qlkhuyenmai.Name = "qlkhuyenmai";
            this.qlkhuyenmai.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlkhuyenmai.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlkhuyenmai.OnHoverTextColor = System.Drawing.Color.White;
            this.qlkhuyenmai.Size = new System.Drawing.Size(229, 38);
            this.qlkhuyenmai.TabIndex = 23;
            this.qlkhuyenmai.Text = "Quản Lý Khuyến Mãi";
            this.qlkhuyenmai.TextColor = System.Drawing.Color.Black;
            this.qlkhuyenmai.UseVisualStyleBackColor = true;
            this.qlkhuyenmai.Click += new System.EventHandler(this.qlkhuyenmai_Click);
            // 
            // qldoitac
            // 
            this.qldoitac.BorderColor = System.Drawing.Color.Black;
            this.qldoitac.ButtonColor = System.Drawing.Color.White;
            this.qldoitac.FlatAppearance.BorderSize = 0;
            this.qldoitac.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qldoitac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qldoitac.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qldoitac.Location = new System.Drawing.Point(37, 251);
            this.qldoitac.Name = "qldoitac";
            this.qldoitac.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qldoitac.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qldoitac.OnHoverTextColor = System.Drawing.Color.White;
            this.qldoitac.Size = new System.Drawing.Size(229, 38);
            this.qldoitac.TabIndex = 22;
            this.qldoitac.Text = "Quản Lý Đối Tác";
            this.qldoitac.TextColor = System.Drawing.Color.Black;
            this.qldoitac.UseVisualStyleBackColor = true;
            this.qldoitac.Click += new System.EventHandler(this.qldoitac_Click);
            // 
            // qlnhanvien
            // 
            this.qlnhanvien.BorderColor = System.Drawing.Color.Black;
            this.qlnhanvien.ButtonColor = System.Drawing.Color.White;
            this.qlnhanvien.FlatAppearance.BorderSize = 0;
            this.qlnhanvien.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlnhanvien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlnhanvien.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlnhanvien.Location = new System.Drawing.Point(37, 197);
            this.qlnhanvien.Name = "qlnhanvien";
            this.qlnhanvien.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlnhanvien.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlnhanvien.OnHoverTextColor = System.Drawing.Color.White;
            this.qlnhanvien.Size = new System.Drawing.Size(229, 38);
            this.qlnhanvien.TabIndex = 21;
            this.qlnhanvien.Text = "Quản Lý Nhân Viên";
            this.qlnhanvien.TextColor = System.Drawing.Color.Black;
            this.qlnhanvien.UseVisualStyleBackColor = true;
            this.qlnhanvien.Click += new System.EventHandler(this.qlnhanvien_Click);
            // 
            // qlsanpham
            // 
            this.qlsanpham.BorderColor = System.Drawing.Color.Black;
            this.qlsanpham.ButtonColor = System.Drawing.Color.White;
            this.qlsanpham.FlatAppearance.BorderSize = 0;
            this.qlsanpham.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.qlsanpham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qlsanpham.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qlsanpham.Location = new System.Drawing.Point(317, 197);
            this.qlsanpham.Name = "qlsanpham";
            this.qlsanpham.OnHoverBorderColor = System.Drawing.Color.Black;
            this.qlsanpham.OnHoverButtonColor = System.Drawing.Color.Black;
            this.qlsanpham.OnHoverTextColor = System.Drawing.Color.White;
            this.qlsanpham.Size = new System.Drawing.Size(229, 38);
            this.qlsanpham.TabIndex = 20;
            this.qlsanpham.Text = "Quản Lý Sản Phẩm";
            this.qlsanpham.TextColor = System.Drawing.Color.Black;
            this.qlsanpham.UseVisualStyleBackColor = true;
            this.qlsanpham.Click += new System.EventHandler(this.qlsanpham_Click);
            // 
            // Admin_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(880, 457);
            this.Controls.Add(this.qlphieudv);
            this.Controls.Add(this.tkdoanhthu);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.qlkhachhang);
            this.Controls.Add(this.qlnhaphang);
            this.Controls.Add(this.qldichvu);
            this.Controls.Add(this.qlhoadon);
            this.Controls.Add(this.qlvatlieu);
            this.Controls.Add(this.qlkhuyenmai);
            this.Controls.Add(this.qldoitac);
            this.Controls.Add(this.qlnhanvien);
            this.Controls.Add(this.qlsanpham);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Admin_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Quản Lý";
            this.Load += new System.EventHandler(this.Admin_Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private ePOSOne.btnProduct.Button_WOC qlsanpham;
        private ePOSOne.btnProduct.Button_WOC qlnhanvien;
        private ePOSOne.btnProduct.Button_WOC qldoitac;
        private ePOSOne.btnProduct.Button_WOC qlkhuyenmai;
        private ePOSOne.btnProduct.Button_WOC qlvatlieu;
        private ePOSOne.btnProduct.Button_WOC qlhoadon;
        private ePOSOne.btnProduct.Button_WOC qldichvu;
        private ePOSOne.btnProduct.Button_WOC qlnhaphang;
        private ePOSOne.btnProduct.Button_WOC qlkhachhang;
        private System.Windows.Forms.Label label4;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private ePOSOne.btnProduct.Button_WOC tkdoanhthu;
        private ePOSOne.btnProduct.Button_WOC qlphieudv;
    }
}