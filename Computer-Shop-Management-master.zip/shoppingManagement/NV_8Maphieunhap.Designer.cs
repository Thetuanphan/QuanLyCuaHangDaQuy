﻿
namespace shoppingManagement
{
    partial class NV_8Maphieunhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NV_8Maphieunhap));
            this.MaKH = new JMaterialTextbox.JMaterialTextbox();
            this.passtxt = new JMaterialTextbox.JMaterialTextbox();
            this.usertxt = new JMaterialTextbox.JMaterialTextbox();
            this.MaHD = new JMaterialTextbox.JMaterialTextbox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC1 = new ePOSOne.btnProduct.Button_WOC();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MaKH
            // 
            this.MaKH.BackColor = System.Drawing.Color.Transparent;
            this.MaKH.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.ForeColors = System.Drawing.Color.Transparent;
            this.MaKH.HintText = null;
            this.MaKH.IsPassword = false;
            this.MaKH.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MaKH.LineThickness = 2;
            this.MaKH.Location = new System.Drawing.Point(9, 117);
            this.MaKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaKH.MaxLength = 32767;
            this.MaKH.Name = "MaKH";
            this.MaKH.OnFocusedColor = System.Drawing.Color.Black;
            this.MaKH.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaKH.ReadOnly = false;
            this.MaKH.Size = new System.Drawing.Size(10, 10);
            this.MaKH.TabIndex = 188;
            this.MaKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaKH.TextName = "";
            // 
            // passtxt
            // 
            this.passtxt.BackColor = System.Drawing.Color.Transparent;
            this.passtxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.ForeColors = System.Drawing.Color.Transparent;
            this.passtxt.HintText = null;
            this.passtxt.IsPassword = false;
            this.passtxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.passtxt.LineThickness = 2;
            this.passtxt.Location = new System.Drawing.Point(10, 37);
            this.passtxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passtxt.MaxLength = 32767;
            this.passtxt.Name = "passtxt";
            this.passtxt.OnFocusedColor = System.Drawing.Color.Black;
            this.passtxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.passtxt.ReadOnly = false;
            this.passtxt.Size = new System.Drawing.Size(10, 10);
            this.passtxt.TabIndex = 186;
            this.passtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passtxt.TextName = "";
            // 
            // usertxt
            // 
            this.usertxt.BackColor = System.Drawing.Color.Transparent;
            this.usertxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.ForeColors = System.Drawing.Color.Transparent;
            this.usertxt.HintText = null;
            this.usertxt.IsPassword = false;
            this.usertxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.usertxt.LineThickness = 2;
            this.usertxt.Location = new System.Drawing.Point(10, 19);
            this.usertxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usertxt.MaxLength = 32767;
            this.usertxt.Name = "usertxt";
            this.usertxt.OnFocusedColor = System.Drawing.Color.Black;
            this.usertxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.usertxt.ReadOnly = false;
            this.usertxt.Size = new System.Drawing.Size(10, 10);
            this.usertxt.TabIndex = 185;
            this.usertxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.usertxt.TextName = "";
            // 
            // MaHD
            // 
            this.MaHD.BackColor = System.Drawing.Color.Transparent;
            this.MaHD.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaHD.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaHD.ForeColors = System.Drawing.Color.Black;
            this.MaHD.HintText = null;
            this.MaHD.IsPassword = false;
            this.MaHD.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaHD.LineThickness = 2;
            this.MaHD.Location = new System.Drawing.Point(202, 174);
            this.MaHD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaHD.MaxLength = 32767;
            this.MaHD.Name = "MaHD";
            this.MaHD.OnFocusedColor = System.Drawing.Color.Black;
            this.MaHD.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaHD.ReadOnly = false;
            this.MaHD.Size = new System.Drawing.Size(159, 23);
            this.MaHD.TabIndex = 184;
            this.MaHD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaHD.TextName = "";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(44, 137);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(131, 222);
            this.dataGridView1.TabIndex = 183;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(187, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(435, 31);
            this.label2.TabIndex = 181;
            this.label2.Text = "MỜI BẠN NHẬP MÃ PHIẾU NHẬP";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(9, 8);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 187;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // button_WOC1
            // 
            this.button_WOC1.BorderColor = System.Drawing.Color.Black;
            this.button_WOC1.ButtonColor = System.Drawing.Color.White;
            this.button_WOC1.FlatAppearance.BorderSize = 0;
            this.button_WOC1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button_WOC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC1.Location = new System.Drawing.Point(202, 272);
            this.button_WOC1.Name = "button_WOC1";
            this.button_WOC1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.button_WOC1.OnHoverButtonColor = System.Drawing.Color.Black;
            this.button_WOC1.OnHoverTextColor = System.Drawing.Color.White;
            this.button_WOC1.Size = new System.Drawing.Size(159, 52);
            this.button_WOC1.TabIndex = 182;
            this.button_WOC1.Text = "Tiếp Tục";
            this.button_WOC1.TextColor = System.Drawing.Color.Black;
            this.button_WOC1.UseVisualStyleBackColor = true;
            this.button_WOC1.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(398, 86);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(429, 369);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 192;
            this.pictureBox1.TabStop = false;
            // 
            // NV_8Maphieunhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(839, 459);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.MaKH);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.MaHD);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_WOC1);
            this.Controls.Add(this.label2);
            this.Name = "NV_8Maphieunhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tạo Phiếu Nhập Hàng";
            this.Load += new System.EventHandler(this.NV_8Maphieunhap_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JMaterialTextbox.JMaterialTextbox MaKH;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private JMaterialTextbox.JMaterialTextbox passtxt;
        private JMaterialTextbox.JMaterialTextbox usertxt;
        private JMaterialTextbox.JMaterialTextbox MaHD;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ePOSOne.btnProduct.Button_WOC button_WOC1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}