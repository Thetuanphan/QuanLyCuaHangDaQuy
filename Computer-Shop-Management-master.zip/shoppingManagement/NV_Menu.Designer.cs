﻿
namespace shoppingManagement
{
    partial class NV_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nhanvien = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC1 = new ePOSOne.btnProduct.Button_WOC();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.usertxt = new JMaterialTextbox.JMaterialTextbox();
            this.passtxt = new JMaterialTextbox.JMaterialTextbox();
            this.button_WOC2 = new ePOSOne.btnProduct.Button_WOC();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.SuspendLayout();
            // 
            // nhanvien
            // 
            this.nhanvien.BorderColor = System.Drawing.Color.Black;
            this.nhanvien.ButtonColor = System.Drawing.Color.Black;
            this.nhanvien.FlatAppearance.BorderSize = 0;
            this.nhanvien.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.nhanvien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nhanvien.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhanvien.Location = new System.Drawing.Point(305, 294);
            this.nhanvien.Name = "nhanvien";
            this.nhanvien.OnHoverBorderColor = System.Drawing.Color.Black;
            this.nhanvien.OnHoverButtonColor = System.Drawing.Color.White;
            this.nhanvien.OnHoverTextColor = System.Drawing.Color.Black;
            this.nhanvien.Size = new System.Drawing.Size(223, 52);
            this.nhanvien.TabIndex = 13;
            this.nhanvien.Text = "LẬP PHIẾU DỊCH VỤ";
            this.nhanvien.TextColor = System.Drawing.Color.White;
            this.nhanvien.UseVisualStyleBackColor = true;
            this.nhanvien.Click += new System.EventHandler(this.nhanvien_Click);
            // 
            // button_WOC1
            // 
            this.button_WOC1.BorderColor = System.Drawing.Color.Black;
            this.button_WOC1.ButtonColor = System.Drawing.Color.White;
            this.button_WOC1.FlatAppearance.BorderSize = 0;
            this.button_WOC1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button_WOC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC1.Location = new System.Drawing.Point(305, 223);
            this.button_WOC1.Name = "button_WOC1";
            this.button_WOC1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.button_WOC1.OnHoverButtonColor = System.Drawing.Color.Black;
            this.button_WOC1.OnHoverTextColor = System.Drawing.Color.White;
            this.button_WOC1.Size = new System.Drawing.Size(223, 52);
            this.button_WOC1.TabIndex = 12;
            this.button_WOC1.Text = "LẬP HÓA ĐƠN";
            this.button_WOC1.TextColor = System.Drawing.Color.Black;
            this.button_WOC1.UseVisualStyleBackColor = true;
            this.button_WOC1.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(218, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(394, 31);
            this.label2.TabIndex = 11;
            this.label2.Text = "MỜI BẠN CHỌN CHỨC NĂNG";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(170, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(498, 56);
            this.label1.TabIndex = 10;
            this.label1.Text = "CỬA HÀNG ĐÁ QUÝ ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // usertxt
            // 
            this.usertxt.BackColor = System.Drawing.Color.Transparent;
            this.usertxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.ForeColors = System.Drawing.Color.Transparent;
            this.usertxt.HintText = null;
            this.usertxt.IsPassword = false;
            this.usertxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.usertxt.LineThickness = 2;
            this.usertxt.Location = new System.Drawing.Point(38, 77);
            this.usertxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usertxt.MaxLength = 32767;
            this.usertxt.Name = "usertxt";
            this.usertxt.OnFocusedColor = System.Drawing.Color.Black;
            this.usertxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.usertxt.ReadOnly = false;
            this.usertxt.Size = new System.Drawing.Size(10, 10);
            this.usertxt.TabIndex = 86;
            this.usertxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.usertxt.TextName = "";
            // 
            // passtxt
            // 
            this.passtxt.BackColor = System.Drawing.Color.Transparent;
            this.passtxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.ForeColors = System.Drawing.Color.Transparent;
            this.passtxt.HintText = null;
            this.passtxt.IsPassword = false;
            this.passtxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.passtxt.LineThickness = 2;
            this.passtxt.Location = new System.Drawing.Point(38, 95);
            this.passtxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passtxt.MaxLength = 32767;
            this.passtxt.Name = "passtxt";
            this.passtxt.OnFocusedColor = System.Drawing.Color.Black;
            this.passtxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.passtxt.ReadOnly = false;
            this.passtxt.Size = new System.Drawing.Size(10, 10);
            this.passtxt.TabIndex = 87;
            this.passtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passtxt.TextName = "";
            // 
            // button_WOC2
            // 
            this.button_WOC2.BorderColor = System.Drawing.Color.Black;
            this.button_WOC2.ButtonColor = System.Drawing.Color.White;
            this.button_WOC2.FlatAppearance.BorderSize = 0;
            this.button_WOC2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button_WOC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC2.Location = new System.Drawing.Point(305, 369);
            this.button_WOC2.Name = "button_WOC2";
            this.button_WOC2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.button_WOC2.OnHoverButtonColor = System.Drawing.Color.Black;
            this.button_WOC2.OnHoverTextColor = System.Drawing.Color.White;
            this.button_WOC2.Size = new System.Drawing.Size(223, 52);
            this.button_WOC2.TabIndex = 88;
            this.button_WOC2.Text = "LẬP PHIẾU NHẬP HÀNG";
            this.button_WOC2.TextColor = System.Drawing.Color.Black;
            this.button_WOC2.UseVisualStyleBackColor = true;
            this.button_WOC2.Click += new System.EventHandler(this.button_WOC2_Click);
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(12, 12);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 152;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // NV_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(839, 459);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.button_WOC2);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.nhanvien);
            this.Controls.Add(this.button_WOC1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "NV_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Nhân Viên";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC nhanvien;
        private ePOSOne.btnProduct.Button_WOC button_WOC1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private JMaterialTextbox.JMaterialTextbox usertxt;
        private JMaterialTextbox.JMaterialTextbox passtxt;
        private ePOSOne.btnProduct.Button_WOC button_WOC2;
        private ePOSOne.btnProduct.Button_WOC quayve;
    }
}