﻿
namespace shoppingManagement
{
    partial class NV_7Doitac
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NV_7Doitac));
            this.timkiem = new ePOSOne.btnProduct.Button_WOC();
            this.TraCuu = new JMaterialTextbox.JMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.LoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.GhiChu = new JMaterialTextbox.JMaterialTextbox();
            this.sdt = new JMaterialTextbox.JMaterialTextbox();
            this.DiaChi = new JMaterialTextbox.JMaterialTextbox();
            this.TenDT = new JMaterialTextbox.JMaterialTextbox();
            this.MaDT = new JMaterialTextbox.JMaterialTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.lammoi = new ePOSOne.btnProduct.Button_WOC();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tieptuc = new ePOSOne.btnProduct.Button_WOC();
            this.passtxt = new JMaterialTextbox.JMaterialTextbox();
            this.usertxt = new JMaterialTextbox.JMaterialTextbox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // timkiem
            // 
            this.timkiem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.BorderColor = System.Drawing.Color.Black;
            this.timkiem.ButtonColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderSize = 0;
            this.timkiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timkiem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timkiem.Location = new System.Drawing.Point(793, 20);
            this.timkiem.Name = "timkiem";
            this.timkiem.OnHoverBorderColor = System.Drawing.Color.Black;
            this.timkiem.OnHoverButtonColor = System.Drawing.Color.White;
            this.timkiem.OnHoverTextColor = System.Drawing.Color.Black;
            this.timkiem.Size = new System.Drawing.Size(58, 38);
            this.timkiem.TabIndex = 120;
            this.timkiem.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.UseVisualStyleBackColor = false;
            this.timkiem.Click += new System.EventHandler(this.timkiem_Click);
            // 
            // TraCuu
            // 
            this.TraCuu.BackColor = System.Drawing.Color.Transparent;
            this.TraCuu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.ForeColors = System.Drawing.Color.Black;
            this.TraCuu.HintText = null;
            this.TraCuu.IsPassword = false;
            this.TraCuu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TraCuu.LineThickness = 2;
            this.TraCuu.Location = new System.Drawing.Point(515, 31);
            this.TraCuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TraCuu.MaxLength = 32767;
            this.TraCuu.Name = "TraCuu";
            this.TraCuu.OnFocusedColor = System.Drawing.Color.Black;
            this.TraCuu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TraCuu.ReadOnly = false;
            this.TraCuu.Size = new System.Drawing.Size(255, 23);
            this.TraCuu.TabIndex = 119;
            this.TraCuu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TraCuu.TextName = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(388, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 19);
            this.label11.TabIndex = 118;
            this.label11.Text = "Nhập từ khóa:";
            // 
            // LoaiTimKiem
            // 
            this.LoaiTimKiem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaiTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaiTimKiem.FormattingEnabled = true;
            this.LoaiTimKiem.Items.AddRange(new object[] {
            "TenCTY",
            "MaDT",
            "SDT"});
            this.LoaiTimKiem.Location = new System.Drawing.Point(286, 31);
            this.LoaiTimKiem.Name = "LoaiTimKiem";
            this.LoaiTimKiem.Size = new System.Drawing.Size(92, 21);
            this.LoaiTimKiem.TabIndex = 117;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(159, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 19);
            this.label6.TabIndex = 116;
            this.label6.Text = "Tìm kiếm theo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 19);
            this.label5.TabIndex = 115;
            this.label5.Text = "Bảng đối tác:";
            // 
            // GhiChu
            // 
            this.GhiChu.BackColor = System.Drawing.Color.Transparent;
            this.GhiChu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.GhiChu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.GhiChu.ForeColors = System.Drawing.Color.Black;
            this.GhiChu.HintText = null;
            this.GhiChu.IsPassword = false;
            this.GhiChu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GhiChu.LineThickness = 2;
            this.GhiChu.Location = new System.Drawing.Point(163, 222);
            this.GhiChu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.GhiChu.MaxLength = 32767;
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.OnFocusedColor = System.Drawing.Color.Black;
            this.GhiChu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.GhiChu.ReadOnly = false;
            this.GhiChu.Size = new System.Drawing.Size(309, 18);
            this.GhiChu.TabIndex = 114;
            this.GhiChu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.GhiChu.TextName = "";
            // 
            // sdt
            // 
            this.sdt.BackColor = System.Drawing.Color.Transparent;
            this.sdt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.ForeColors = System.Drawing.Color.Black;
            this.sdt.HintText = null;
            this.sdt.IsPassword = false;
            this.sdt.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sdt.LineThickness = 2;
            this.sdt.Location = new System.Drawing.Point(515, 164);
            this.sdt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sdt.MaxLength = 32767;
            this.sdt.Name = "sdt";
            this.sdt.OnFocusedColor = System.Drawing.Color.Black;
            this.sdt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.sdt.ReadOnly = false;
            this.sdt.Size = new System.Drawing.Size(255, 18);
            this.sdt.TabIndex = 113;
            this.sdt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sdt.TextName = "";
            // 
            // DiaChi
            // 
            this.DiaChi.BackColor = System.Drawing.Color.Transparent;
            this.DiaChi.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DiaChi.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DiaChi.ForeColors = System.Drawing.Color.Black;
            this.DiaChi.HintText = null;
            this.DiaChi.IsPassword = false;
            this.DiaChi.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DiaChi.LineThickness = 2;
            this.DiaChi.Location = new System.Drawing.Point(515, 103);
            this.DiaChi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DiaChi.MaxLength = 32767;
            this.DiaChi.Name = "DiaChi";
            this.DiaChi.OnFocusedColor = System.Drawing.Color.Black;
            this.DiaChi.OnFocusedTextColor = System.Drawing.Color.Black;
            this.DiaChi.ReadOnly = false;
            this.DiaChi.Size = new System.Drawing.Size(336, 18);
            this.DiaChi.TabIndex = 112;
            this.DiaChi.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.DiaChi.TextName = "";
            // 
            // TenDT
            // 
            this.TenDT.BackColor = System.Drawing.Color.Transparent;
            this.TenDT.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenDT.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenDT.ForeColors = System.Drawing.Color.Black;
            this.TenDT.HintText = null;
            this.TenDT.IsPassword = false;
            this.TenDT.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TenDT.LineThickness = 2;
            this.TenDT.Location = new System.Drawing.Point(163, 165);
            this.TenDT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TenDT.MaxLength = 32767;
            this.TenDT.Name = "TenDT";
            this.TenDT.OnFocusedColor = System.Drawing.Color.Black;
            this.TenDT.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TenDT.ReadOnly = false;
            this.TenDT.Size = new System.Drawing.Size(202, 18);
            this.TenDT.TabIndex = 111;
            this.TenDT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TenDT.TextName = "";
            // 
            // MaDT
            // 
            this.MaDT.BackColor = System.Drawing.Color.Transparent;
            this.MaDT.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaDT.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaDT.ForeColors = System.Drawing.Color.Black;
            this.MaDT.HintText = null;
            this.MaDT.IsPassword = false;
            this.MaDT.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaDT.LineThickness = 2;
            this.MaDT.Location = new System.Drawing.Point(163, 99);
            this.MaDT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaDT.MaxLength = 32767;
            this.MaDT.Name = "MaDT";
            this.MaDT.OnFocusedColor = System.Drawing.Color.Black;
            this.MaDT.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaDT.ReadOnly = false;
            this.MaDT.Size = new System.Drawing.Size(202, 23);
            this.MaDT.TabIndex = 110;
            this.MaDT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaDT.TextName = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 19);
            this.label1.TabIndex = 109;
            this.label1.Text = "Tên công ty:";
            // 
            // lammoi
            // 
            this.lammoi.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lammoi.BorderColor = System.Drawing.Color.Black;
            this.lammoi.ButtonColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lammoi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderSize = 0;
            this.lammoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.lammoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lammoi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lammoi.Location = new System.Drawing.Point(877, 20);
            this.lammoi.Name = "lammoi";
            this.lammoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverButtonColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverTextColor = System.Drawing.Color.White;
            this.lammoi.Size = new System.Drawing.Size(58, 38);
            this.lammoi.TabIndex = 108;
            this.lammoi.TextColor = System.Drawing.Color.Black;
            this.lammoi.UseVisualStyleBackColor = false;
            this.lammoi.Click += new System.EventHandler(this.lammoi_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(24, 221);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 19);
            this.label10.TabIndex = 104;
            this.label10.Text = "Ghi chú: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(405, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 19);
            this.label9.TabIndex = 103;
            this.label9.Text = "SĐT: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(405, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 19);
            this.label8.TabIndex = 102;
            this.label8.Text = "Địa chỉ:";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(21, 20);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 101;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 19);
            this.label3.TabIndex = 100;
            this.label3.Text = "Mã đối tác:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(30, 301);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(544, 319);
            this.dataGridView1.TabIndex = 99;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // tieptuc
            // 
            this.tieptuc.BorderColor = System.Drawing.Color.Black;
            this.tieptuc.ButtonColor = System.Drawing.Color.White;
            this.tieptuc.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.tieptuc.FlatAppearance.BorderSize = 0;
            this.tieptuc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.tieptuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tieptuc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tieptuc.Location = new System.Drawing.Point(790, 212);
            this.tieptuc.Name = "tieptuc";
            this.tieptuc.OnHoverBorderColor = System.Drawing.Color.Black;
            this.tieptuc.OnHoverButtonColor = System.Drawing.Color.Black;
            this.tieptuc.OnHoverTextColor = System.Drawing.Color.White;
            this.tieptuc.Size = new System.Drawing.Size(145, 39);
            this.tieptuc.TabIndex = 121;
            this.tieptuc.Text = "Tiếp Tục";
            this.tieptuc.TextColor = System.Drawing.Color.Black;
            this.tieptuc.UseVisualStyleBackColor = true;
            this.tieptuc.Click += new System.EventHandler(this.tieptuc_Click);
            // 
            // passtxt
            // 
            this.passtxt.BackColor = System.Drawing.Color.Transparent;
            this.passtxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.ForeColors = System.Drawing.Color.Transparent;
            this.passtxt.HintText = null;
            this.passtxt.IsPassword = false;
            this.passtxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.passtxt.LineThickness = 2;
            this.passtxt.Location = new System.Drawing.Point(13, 580);
            this.passtxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passtxt.MaxLength = 32767;
            this.passtxt.Name = "passtxt";
            this.passtxt.OnFocusedColor = System.Drawing.Color.Black;
            this.passtxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.passtxt.ReadOnly = false;
            this.passtxt.Size = new System.Drawing.Size(10, 10);
            this.passtxt.TabIndex = 181;
            this.passtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passtxt.TextName = "";
            // 
            // usertxt
            // 
            this.usertxt.BackColor = System.Drawing.Color.Transparent;
            this.usertxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.ForeColors = System.Drawing.Color.Transparent;
            this.usertxt.HintText = null;
            this.usertxt.IsPassword = false;
            this.usertxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.usertxt.LineThickness = 2;
            this.usertxt.Location = new System.Drawing.Point(13, 562);
            this.usertxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usertxt.MaxLength = 32767;
            this.usertxt.Name = "usertxt";
            this.usertxt.OnFocusedColor = System.Drawing.Color.Black;
            this.usertxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.usertxt.ReadOnly = false;
            this.usertxt.Size = new System.Drawing.Size(10, 10);
            this.usertxt.TabIndex = 180;
            this.usertxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.usertxt.TextName = "";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(898, 27);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 183;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(812, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 182;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(595, 284);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(410, 336);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 184;
            this.pictureBox5.TabStop = false;
            // 
            // NV_7Doitac
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.tieptuc);
            this.Controls.Add(this.timkiem);
            this.Controls.Add(this.TraCuu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LoaiTimKiem);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.GhiChu);
            this.Controls.Add(this.sdt);
            this.Controls.Add(this.DiaChi);
            this.Controls.Add(this.TenDT);
            this.Controls.Add(this.MaDT);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lammoi);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Name = "NV_7Doitac";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chọn Đối Tác";
            this.Load += new System.EventHandler(this.NV_7Doitac_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC timkiem;
        private JMaterialTextbox.JMaterialTextbox TraCuu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox LoaiTimKiem;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private JMaterialTextbox.JMaterialTextbox GhiChu;
        private JMaterialTextbox.JMaterialTextbox sdt;
        private JMaterialTextbox.JMaterialTextbox DiaChi;
        private JMaterialTextbox.JMaterialTextbox TenDT;
        private JMaterialTextbox.JMaterialTextbox MaDT;
        private System.Windows.Forms.Label label1;
        private ePOSOne.btnProduct.Button_WOC lammoi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ePOSOne.btnProduct.Button_WOC tieptuc;
        private JMaterialTextbox.JMaterialTextbox passtxt;
        private JMaterialTextbox.JMaterialTextbox usertxt;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}