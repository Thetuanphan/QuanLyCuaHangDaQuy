﻿
namespace shoppingManagement
{
    partial class Admin_Nhanvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Nhanvien));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.them = new ePOSOne.btnProduct.Button_WOC();
            this.xoa = new ePOSOne.btnProduct.Button_WOC();
            this.capnhat = new ePOSOne.btnProduct.Button_WOC();
            this.lammoi = new ePOSOne.btnProduct.Button_WOC();
            this.label1 = new System.Windows.Forms.Label();
            this.MaNV = new JMaterialTextbox.JMaterialTextbox();
            this.MaQL = new JMaterialTextbox.JMaterialTextbox();
            this.TenNV = new JMaterialTextbox.JMaterialTextbox();
            this.ChucVu = new JMaterialTextbox.JMaterialTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.TraCuu = new JMaterialTextbox.JMaterialTextbox();
            this.timkiem = new ePOSOne.btnProduct.Button_WOC();
            this.label2 = new System.Windows.Forms.Label();
            this.dVaoLam = new JMaterialTextbox.JMaterialTextbox();
            this.label14 = new System.Windows.Forms.Label();
            this.GioiTinh = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.DiaChi = new JMaterialTextbox.JMaterialTextbox();
            this.label16 = new System.Windows.Forms.Label();
            this.sdt = new JMaterialTextbox.JMaterialTextbox();
            this.dSinh = new JMaterialTextbox.JMaterialTextbox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(34, 338);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(937, 282);
            this.dataGridView1.TabIndex = 71;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 19);
            this.label3.TabIndex = 73;
            this.label3.Text = "Mã nhân viên:";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(21, 27);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 74;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(483, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 19);
            this.label8.TabIndex = 76;
            this.label8.Text = "Tên nhân viên:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 19);
            this.label9.TabIndex = 77;
            this.label9.Text = "Chức vụ:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(631, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 19);
            this.label10.TabIndex = 78;
            this.label10.Text = "Giới tính:";
            // 
            // them
            // 
            this.them.BorderColor = System.Drawing.Color.Black;
            this.them.ButtonColor = System.Drawing.Color.White;
            this.them.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.them.FlatAppearance.BorderSize = 0;
            this.them.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.them.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.them.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.them.Location = new System.Drawing.Point(691, 276);
            this.them.Name = "them";
            this.them.OnHoverBorderColor = System.Drawing.Color.Black;
            this.them.OnHoverButtonColor = System.Drawing.Color.White;
            this.them.OnHoverTextColor = System.Drawing.Color.Black;
            this.them.Size = new System.Drawing.Size(58, 38);
            this.them.TabIndex = 79;
            this.them.Text = " ";
            this.them.TextColor = System.Drawing.Color.White;
            this.them.UseVisualStyleBackColor = true;
            this.them.Click += new System.EventHandler(this.them_Click);
            // 
            // xoa
            // 
            this.xoa.BorderColor = System.Drawing.Color.Black;
            this.xoa.ButtonColor = System.Drawing.Color.White;
            this.xoa.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.xoa.FlatAppearance.BorderSize = 0;
            this.xoa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.xoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xoa.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xoa.Location = new System.Drawing.Point(902, 276);
            this.xoa.Name = "xoa";
            this.xoa.OnHoverBorderColor = System.Drawing.Color.Black;
            this.xoa.OnHoverButtonColor = System.Drawing.Color.White;
            this.xoa.OnHoverTextColor = System.Drawing.Color.Black;
            this.xoa.Size = new System.Drawing.Size(58, 38);
            this.xoa.TabIndex = 80;
            this.xoa.Text = " ";
            this.xoa.TextColor = System.Drawing.Color.White;
            this.xoa.UseVisualStyleBackColor = true;
            this.xoa.Click += new System.EventHandler(this.xoa_Click);
            // 
            // capnhat
            // 
            this.capnhat.BorderColor = System.Drawing.Color.Black;
            this.capnhat.ButtonColor = System.Drawing.Color.White;
            this.capnhat.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.capnhat.FlatAppearance.BorderSize = 0;
            this.capnhat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.capnhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.capnhat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capnhat.Location = new System.Drawing.Point(793, 276);
            this.capnhat.Name = "capnhat";
            this.capnhat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.capnhat.OnHoverButtonColor = System.Drawing.Color.White;
            this.capnhat.OnHoverTextColor = System.Drawing.Color.Black;
            this.capnhat.Size = new System.Drawing.Size(58, 38);
            this.capnhat.TabIndex = 81;
            this.capnhat.Text = " ";
            this.capnhat.TextColor = System.Drawing.Color.White;
            this.capnhat.UseVisualStyleBackColor = true;
            this.capnhat.Click += new System.EventHandler(this.capnhat_Click);
            // 
            // lammoi
            // 
            this.lammoi.BorderColor = System.Drawing.Color.Black;
            this.lammoi.ButtonColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderSize = 0;
            this.lammoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.lammoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lammoi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lammoi.Location = new System.Drawing.Point(871, 36);
            this.lammoi.Name = "lammoi";
            this.lammoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverButtonColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverTextColor = System.Drawing.Color.White;
            this.lammoi.Size = new System.Drawing.Size(58, 38);
            this.lammoi.TabIndex = 83;
            this.lammoi.Text = " ";
            this.lammoi.TextColor = System.Drawing.Color.Black;
            this.lammoi.UseVisualStyleBackColor = true;
            this.lammoi.Click += new System.EventHandler(this.lammoi_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(244, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 19);
            this.label1.TabIndex = 84;
            this.label1.Text = "Mã quản lý:";
            // 
            // MaNV
            // 
            this.MaNV.BackColor = System.Drawing.Color.Transparent;
            this.MaNV.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaNV.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaNV.ForeColors = System.Drawing.Color.Black;
            this.MaNV.HintText = null;
            this.MaNV.IsPassword = false;
            this.MaNV.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaNV.LineThickness = 2;
            this.MaNV.Location = new System.Drawing.Point(147, 112);
            this.MaNV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaNV.MaxLength = 32767;
            this.MaNV.Name = "MaNV";
            this.MaNV.OnFocusedColor = System.Drawing.Color.Black;
            this.MaNV.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaNV.ReadOnly = false;
            this.MaNV.Size = new System.Drawing.Size(69, 23);
            this.MaNV.TabIndex = 85;
            this.MaNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaNV.TextName = "";
            // 
            // MaQL
            // 
            this.MaQL.BackColor = System.Drawing.Color.Transparent;
            this.MaQL.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaQL.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaQL.ForeColors = System.Drawing.Color.Black;
            this.MaQL.HintText = null;
            this.MaQL.IsPassword = false;
            this.MaQL.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaQL.LineThickness = 2;
            this.MaQL.Location = new System.Drawing.Point(354, 116);
            this.MaQL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaQL.MaxLength = 32767;
            this.MaQL.Name = "MaQL";
            this.MaQL.OnFocusedColor = System.Drawing.Color.Black;
            this.MaQL.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaQL.ReadOnly = false;
            this.MaQL.Size = new System.Drawing.Size(69, 18);
            this.MaQL.TabIndex = 86;
            this.MaQL.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaQL.TextName = "";
            // 
            // TenNV
            // 
            this.TenNV.BackColor = System.Drawing.Color.Transparent;
            this.TenNV.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenNV.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenNV.ForeColors = System.Drawing.Color.Black;
            this.TenNV.HintText = null;
            this.TenNV.IsPassword = false;
            this.TenNV.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TenNV.LineThickness = 2;
            this.TenNV.Location = new System.Drawing.Point(622, 116);
            this.TenNV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TenNV.MaxLength = 32767;
            this.TenNV.Name = "TenNV";
            this.TenNV.OnFocusedColor = System.Drawing.Color.Black;
            this.TenNV.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TenNV.ReadOnly = false;
            this.TenNV.Size = new System.Drawing.Size(338, 18);
            this.TenNV.TabIndex = 87;
            this.TenNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TenNV.TextName = "";
            // 
            // ChucVu
            // 
            this.ChucVu.BackColor = System.Drawing.Color.Transparent;
            this.ChucVu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.ChucVu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.ChucVu.ForeColors = System.Drawing.Color.Black;
            this.ChucVu.HintText = null;
            this.ChucVu.IsPassword = false;
            this.ChucVu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ChucVu.LineThickness = 2;
            this.ChucVu.Location = new System.Drawing.Point(113, 175);
            this.ChucVu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ChucVu.MaxLength = 32767;
            this.ChucVu.Name = "ChucVu";
            this.ChucVu.OnFocusedColor = System.Drawing.Color.Black;
            this.ChucVu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.ChucVu.ReadOnly = false;
            this.ChucVu.Size = new System.Drawing.Size(228, 18);
            this.ChucVu.TabIndex = 88;
            this.ChucVu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ChucVu.TextName = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 285);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 19);
            this.label5.TabIndex = 93;
            this.label5.Text = "Bảng nhân viên:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(135, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 19);
            this.label6.TabIndex = 94;
            this.label6.Text = "Tìm kiếm theo:";
            // 
            // LoaiTimKiem
            // 
            this.LoaiTimKiem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaiTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaiTimKiem.FormattingEnabled = true;
            this.LoaiTimKiem.Items.AddRange(new object[] {
            "TenNV",
            "MaNV",
            "MaQL"});
            this.LoaiTimKiem.Location = new System.Drawing.Point(262, 40);
            this.LoaiTimKiem.Name = "LoaiTimKiem";
            this.LoaiTimKiem.Size = new System.Drawing.Size(92, 21);
            this.LoaiTimKiem.TabIndex = 95;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(388, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 19);
            this.label11.TabIndex = 96;
            this.label11.Text = "Nhập từ khóa:";
            // 
            // TraCuu
            // 
            this.TraCuu.BackColor = System.Drawing.Color.Transparent;
            this.TraCuu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.ForeColors = System.Drawing.Color.Black;
            this.TraCuu.HintText = null;
            this.TraCuu.IsPassword = false;
            this.TraCuu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TraCuu.LineThickness = 2;
            this.TraCuu.Location = new System.Drawing.Point(515, 38);
            this.TraCuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TraCuu.MaxLength = 32767;
            this.TraCuu.Name = "TraCuu";
            this.TraCuu.OnFocusedColor = System.Drawing.Color.Black;
            this.TraCuu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TraCuu.ReadOnly = false;
            this.TraCuu.Size = new System.Drawing.Size(255, 23);
            this.TraCuu.TabIndex = 97;
            this.TraCuu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TraCuu.TextName = "";
            // 
            // timkiem
            // 
            this.timkiem.BackColor = System.Drawing.Color.White;
            this.timkiem.BorderColor = System.Drawing.Color.Black;
            this.timkiem.ButtonColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderSize = 0;
            this.timkiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timkiem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timkiem.Location = new System.Drawing.Point(794, 36);
            this.timkiem.Name = "timkiem";
            this.timkiem.OnHoverBorderColor = System.Drawing.Color.Black;
            this.timkiem.OnHoverButtonColor = System.Drawing.Color.White;
            this.timkiem.OnHoverTextColor = System.Drawing.Color.Black;
            this.timkiem.Size = new System.Drawing.Size(58, 38);
            this.timkiem.TabIndex = 98;
            this.timkiem.Text = " ";
            this.timkiem.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.UseVisualStyleBackColor = false;
            this.timkiem.Click += new System.EventHandler(this.timkiem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(362, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 19);
            this.label2.TabIndex = 99;
            this.label2.Text = "Ngày vào làm:";
            // 
            // dVaoLam
            // 
            this.dVaoLam.BackColor = System.Drawing.Color.Transparent;
            this.dVaoLam.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dVaoLam.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dVaoLam.ForeColors = System.Drawing.Color.Black;
            this.dVaoLam.HintText = null;
            this.dVaoLam.IsPassword = false;
            this.dVaoLam.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dVaoLam.LineThickness = 2;
            this.dVaoLam.Location = new System.Drawing.Point(487, 171);
            this.dVaoLam.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dVaoLam.MaxLength = 32767;
            this.dVaoLam.Name = "dVaoLam";
            this.dVaoLam.OnFocusedColor = System.Drawing.Color.Black;
            this.dVaoLam.OnFocusedTextColor = System.Drawing.Color.Black;
            this.dVaoLam.ReadOnly = false;
            this.dVaoLam.Size = new System.Drawing.Size(127, 23);
            this.dVaoLam.TabIndex = 103;
            this.dVaoLam.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dVaoLam.TextName = "";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(24, 227);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 19);
            this.label14.TabIndex = 105;
            this.label14.Text = "Ngày sinh:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // GioiTinh
            // 
            this.GioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GioiTinh.FormattingEnabled = true;
            this.GioiTinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khác"});
            this.GioiTinh.Location = new System.Drawing.Point(727, 172);
            this.GioiTinh.Name = "GioiTinh";
            this.GioiTinh.Size = new System.Drawing.Size(92, 21);
            this.GioiTinh.TabIndex = 111;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(631, 227);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 19);
            this.label15.TabIndex = 112;
            this.label15.Text = "Địa chỉ:";
            // 
            // DiaChi
            // 
            this.DiaChi.BackColor = System.Drawing.Color.Transparent;
            this.DiaChi.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DiaChi.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DiaChi.ForeColors = System.Drawing.Color.Black;
            this.DiaChi.HintText = null;
            this.DiaChi.IsPassword = false;
            this.DiaChi.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DiaChi.LineThickness = 2;
            this.DiaChi.Location = new System.Drawing.Point(705, 227);
            this.DiaChi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DiaChi.MaxLength = 32767;
            this.DiaChi.Name = "DiaChi";
            this.DiaChi.OnFocusedColor = System.Drawing.Color.Black;
            this.DiaChi.OnFocusedTextColor = System.Drawing.Color.Black;
            this.DiaChi.ReadOnly = false;
            this.DiaChi.Size = new System.Drawing.Size(255, 18);
            this.DiaChi.TabIndex = 113;
            this.DiaChi.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.DiaChi.TextName = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(362, 227);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 19);
            this.label16.TabIndex = 114;
            this.label16.Text = "SĐT:";
            // 
            // sdt
            // 
            this.sdt.BackColor = System.Drawing.Color.Transparent;
            this.sdt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.ForeColors = System.Drawing.Color.Black;
            this.sdt.HintText = null;
            this.sdt.IsPassword = false;
            this.sdt.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sdt.LineThickness = 2;
            this.sdt.Location = new System.Drawing.Point(415, 227);
            this.sdt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sdt.MaxLength = 32767;
            this.sdt.Name = "sdt";
            this.sdt.OnFocusedColor = System.Drawing.Color.Black;
            this.sdt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.sdt.ReadOnly = false;
            this.sdt.Size = new System.Drawing.Size(199, 18);
            this.sdt.TabIndex = 115;
            this.sdt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sdt.TextName = "";
            // 
            // dSinh
            // 
            this.dSinh.BackColor = System.Drawing.Color.Transparent;
            this.dSinh.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dSinh.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dSinh.ForeColors = System.Drawing.Color.Black;
            this.dSinh.HintText = null;
            this.dSinh.IsPassword = false;
            this.dSinh.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dSinh.LineThickness = 2;
            this.dSinh.Location = new System.Drawing.Point(123, 224);
            this.dSinh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dSinh.MaxLength = 32767;
            this.dSinh.Name = "dSinh";
            this.dSinh.OnFocusedColor = System.Drawing.Color.Black;
            this.dSinh.OnFocusedTextColor = System.Drawing.Color.Black;
            this.dSinh.ReadOnly = false;
            this.dSinh.Size = new System.Drawing.Size(218, 23);
            this.dSinh.TabIndex = 116;
            this.dSinh.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dSinh.TextName = "";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(890, 44);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 137;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(811, 285);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(23, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 136;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(922, 285);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(23, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 135;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(709, 285);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 134;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(812, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 133;
            this.pictureBox1.TabStop = false;
            // 
            // Admin_Nhanvien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dSinh);
            this.Controls.Add(this.sdt);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.DiaChi);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.GioiTinh);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dVaoLam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.timkiem);
            this.Controls.Add(this.TraCuu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LoaiTimKiem);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ChucVu);
            this.Controls.Add(this.TenNV);
            this.Controls.Add(this.MaQL);
            this.Controls.Add(this.MaNV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lammoi);
            this.Controls.Add(this.capnhat);
            this.Controls.Add(this.xoa);
            this.Controls.Add(this.them);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Admin_Nhanvien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Nhân Viên";
            this.Load += new System.EventHandler(this.Admin_Nhanvien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private ePOSOne.btnProduct.Button_WOC them;
        private ePOSOne.btnProduct.Button_WOC xoa;
        private ePOSOne.btnProduct.Button_WOC capnhat;
        private ePOSOne.btnProduct.Button_WOC lammoi;
        private System.Windows.Forms.Label label1;
        private JMaterialTextbox.JMaterialTextbox MaNV;
        private JMaterialTextbox.JMaterialTextbox MaQL;
        private JMaterialTextbox.JMaterialTextbox TenNV;
        private JMaterialTextbox.JMaterialTextbox ChucVu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox LoaiTimKiem;
        private System.Windows.Forms.Label label11;
        private JMaterialTextbox.JMaterialTextbox TraCuu;
        private ePOSOne.btnProduct.Button_WOC timkiem;
        private System.Windows.Forms.Label label2;
        private JMaterialTextbox.JMaterialTextbox dVaoLam;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox GioiTinh;
        private System.Windows.Forms.Label label15;
        private JMaterialTextbox.JMaterialTextbox DiaChi;
        private System.Windows.Forms.Label label16;
        private JMaterialTextbox.JMaterialTextbox sdt;
        private JMaterialTextbox.JMaterialTextbox dSinh;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}