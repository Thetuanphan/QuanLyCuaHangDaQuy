﻿
namespace shoppingManagement
{
    partial class NV_6Dichvu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NV_6Dichvu));
            this.timkiem = new ePOSOne.btnProduct.Button_WOC();
            this.TraCuu = new JMaterialTextbox.JMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.LoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.MaPDV = new JMaterialTextbox.JMaterialTextbox();
            this.txtpass = new JMaterialTextbox.JMaterialTextbox();
            this.txtuser = new JMaterialTextbox.JMaterialTextbox();
            this.MaKH = new JMaterialTextbox.JMaterialTextbox();
            this.lammoi = new ePOSOne.btnProduct.Button_WOC();
            this.tieptuc = new ePOSOne.btnProduct.Button_WOC();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SLsanpham = new JMaterialTextbox.JMaterialTextbox();
            this.themsp = new ePOSOne.btnProduct.Button_WOC();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.MaDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGiaDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TraTruoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConLai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayGiao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txtngaygiao = new JMaterialTextbox.JMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.txttinhtrang = new JMaterialTextbox.JMaterialTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtdongia = new JMaterialTextbox.JMaterialTextbox();
            this.label8 = new System.Windows.Forms.Label();
            this.txttratruoc = new JMaterialTextbox.JMaterialTextbox();
            this.sdt = new JMaterialTextbox.JMaterialTextbox();
            this.TenKH = new JMaterialTextbox.JMaterialTextbox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // timkiem
            // 
            this.timkiem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.BorderColor = System.Drawing.Color.Black;
            this.timkiem.ButtonColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderSize = 0;
            this.timkiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timkiem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timkiem.Location = new System.Drawing.Point(786, 11);
            this.timkiem.Name = "timkiem";
            this.timkiem.OnHoverBorderColor = System.Drawing.Color.Black;
            this.timkiem.OnHoverButtonColor = System.Drawing.Color.White;
            this.timkiem.OnHoverTextColor = System.Drawing.Color.Black;
            this.timkiem.Size = new System.Drawing.Size(58, 38);
            this.timkiem.TabIndex = 212;
            this.timkiem.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.UseVisualStyleBackColor = false;
            // 
            // TraCuu
            // 
            this.TraCuu.BackColor = System.Drawing.Color.Transparent;
            this.TraCuu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.ForeColors = System.Drawing.Color.Black;
            this.TraCuu.HintText = null;
            this.TraCuu.IsPassword = false;
            this.TraCuu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TraCuu.LineThickness = 2;
            this.TraCuu.Location = new System.Drawing.Point(507, 19);
            this.TraCuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TraCuu.MaxLength = 32767;
            this.TraCuu.Name = "TraCuu";
            this.TraCuu.OnFocusedColor = System.Drawing.Color.Black;
            this.TraCuu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TraCuu.ReadOnly = false;
            this.TraCuu.Size = new System.Drawing.Size(255, 23);
            this.TraCuu.TabIndex = 211;
            this.TraCuu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TraCuu.TextName = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(378, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 19);
            this.label11.TabIndex = 210;
            this.label11.Text = "Nhập từ khóa:";
            // 
            // LoaiTimKiem
            // 
            this.LoaiTimKiem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaiTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaiTimKiem.FormattingEnabled = true;
            this.LoaiTimKiem.Items.AddRange(new object[] {
            "MaDV",
            "TenDV"});
            this.LoaiTimKiem.Location = new System.Drawing.Point(250, 20);
            this.LoaiTimKiem.Name = "LoaiTimKiem";
            this.LoaiTimKiem.Size = new System.Drawing.Size(92, 21);
            this.LoaiTimKiem.TabIndex = 209;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(123, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 19);
            this.label6.TabIndex = 208;
            this.label6.Text = "Tìm kiếm theo:";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(12, 12);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 207;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // MaPDV
            // 
            this.MaPDV.BackColor = System.Drawing.Color.Transparent;
            this.MaPDV.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaPDV.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaPDV.ForeColors = System.Drawing.Color.Transparent;
            this.MaPDV.HintText = null;
            this.MaPDV.IsPassword = false;
            this.MaPDV.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MaPDV.LineThickness = 2;
            this.MaPDV.Location = new System.Drawing.Point(31, 610);
            this.MaPDV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaPDV.MaxLength = 32767;
            this.MaPDV.Name = "MaPDV";
            this.MaPDV.OnFocusedColor = System.Drawing.Color.Black;
            this.MaPDV.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaPDV.ReadOnly = false;
            this.MaPDV.Size = new System.Drawing.Size(10, 10);
            this.MaPDV.TabIndex = 206;
            this.MaPDV.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaPDV.TextName = "";
            // 
            // txtpass
            // 
            this.txtpass.BackColor = System.Drawing.Color.Transparent;
            this.txtpass.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtpass.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtpass.ForeColors = System.Drawing.Color.Transparent;
            this.txtpass.HintText = null;
            this.txtpass.IsPassword = false;
            this.txtpass.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtpass.LineThickness = 2;
            this.txtpass.Location = new System.Drawing.Point(31, 600);
            this.txtpass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpass.MaxLength = 32767;
            this.txtpass.Name = "txtpass";
            this.txtpass.OnFocusedColor = System.Drawing.Color.Black;
            this.txtpass.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtpass.ReadOnly = false;
            this.txtpass.Size = new System.Drawing.Size(10, 10);
            this.txtpass.TabIndex = 205;
            this.txtpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtpass.TextName = "";
            // 
            // txtuser
            // 
            this.txtuser.BackColor = System.Drawing.Color.Transparent;
            this.txtuser.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtuser.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtuser.ForeColors = System.Drawing.Color.Transparent;
            this.txtuser.HintText = null;
            this.txtuser.IsPassword = false;
            this.txtuser.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtuser.LineThickness = 2;
            this.txtuser.Location = new System.Drawing.Point(31, 591);
            this.txtuser.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtuser.MaxLength = 32767;
            this.txtuser.Name = "txtuser";
            this.txtuser.OnFocusedColor = System.Drawing.Color.Black;
            this.txtuser.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtuser.ReadOnly = false;
            this.txtuser.Size = new System.Drawing.Size(10, 10);
            this.txtuser.TabIndex = 204;
            this.txtuser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtuser.TextName = "";
            // 
            // MaKH
            // 
            this.MaKH.BackColor = System.Drawing.Color.Transparent;
            this.MaKH.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.ForeColors = System.Drawing.Color.Transparent;
            this.MaKH.HintText = null;
            this.MaKH.IsPassword = false;
            this.MaKH.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MaKH.LineThickness = 2;
            this.MaKH.Location = new System.Drawing.Point(13, 591);
            this.MaKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaKH.MaxLength = 32767;
            this.MaKH.Name = "MaKH";
            this.MaKH.OnFocusedColor = System.Drawing.Color.Black;
            this.MaKH.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaKH.ReadOnly = false;
            this.MaKH.Size = new System.Drawing.Size(10, 10);
            this.MaKH.TabIndex = 203;
            this.MaKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaKH.TextName = "";
            // 
            // lammoi
            // 
            this.lammoi.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lammoi.BorderColor = System.Drawing.Color.Black;
            this.lammoi.ButtonColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lammoi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderSize = 0;
            this.lammoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.lammoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lammoi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lammoi.Location = new System.Drawing.Point(866, 11);
            this.lammoi.Name = "lammoi";
            this.lammoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverButtonColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverTextColor = System.Drawing.Color.White;
            this.lammoi.Size = new System.Drawing.Size(58, 38);
            this.lammoi.TabIndex = 202;
            this.lammoi.TextColor = System.Drawing.Color.Black;
            this.lammoi.UseVisualStyleBackColor = false;
            this.lammoi.Click += new System.EventHandler(this.lammoi_Click);
            // 
            // tieptuc
            // 
            this.tieptuc.BackColor = System.Drawing.Color.White;
            this.tieptuc.BorderColor = System.Drawing.Color.Black;
            this.tieptuc.ButtonColor = System.Drawing.Color.Black;
            this.tieptuc.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.tieptuc.FlatAppearance.BorderSize = 0;
            this.tieptuc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.tieptuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tieptuc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tieptuc.Location = new System.Drawing.Point(850, 584);
            this.tieptuc.Name = "tieptuc";
            this.tieptuc.OnHoverBorderColor = System.Drawing.Color.Black;
            this.tieptuc.OnHoverButtonColor = System.Drawing.Color.White;
            this.tieptuc.OnHoverTextColor = System.Drawing.Color.Black;
            this.tieptuc.Size = new System.Drawing.Size(126, 36);
            this.tieptuc.TabIndex = 198;
            this.tieptuc.Text = "Tạo Phiếu DV";
            this.tieptuc.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tieptuc.UseVisualStyleBackColor = false;
            this.tieptuc.Click += new System.EventHandler(this.tieptuc_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(735, 592);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 19);
            this.label4.TabIndex = 197;
            this.label4.Text = "0 vnđ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(565, 592);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 19);
            this.label1.TabIndex = 196;
            this.label1.Text = "TỔNG CỘNG:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(455, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 19);
            this.label5.TabIndex = 195;
            this.label5.Text = "Số lượng:";
            // 
            // SLsanpham
            // 
            this.SLsanpham.BackColor = System.Drawing.Color.Transparent;
            this.SLsanpham.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.SLsanpham.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.SLsanpham.ForeColors = System.Drawing.Color.Black;
            this.SLsanpham.HintText = null;
            this.SLsanpham.IsPassword = false;
            this.SLsanpham.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SLsanpham.LineThickness = 2;
            this.SLsanpham.Location = new System.Drawing.Point(459, 116);
            this.SLsanpham.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SLsanpham.MaxLength = 32767;
            this.SLsanpham.Name = "SLsanpham";
            this.SLsanpham.OnFocusedColor = System.Drawing.Color.Black;
            this.SLsanpham.OnFocusedTextColor = System.Drawing.Color.Black;
            this.SLsanpham.ReadOnly = false;
            this.SLsanpham.Size = new System.Drawing.Size(115, 23);
            this.SLsanpham.TabIndex = 194;
            this.SLsanpham.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.SLsanpham.TextName = "";
            // 
            // themsp
            // 
            this.themsp.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.themsp.BorderColor = System.Drawing.Color.Black;
            this.themsp.ButtonColor = System.Drawing.SystemColors.ButtonHighlight;
            this.themsp.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.themsp.FlatAppearance.BorderSize = 0;
            this.themsp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.themsp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.themsp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.themsp.Location = new System.Drawing.Point(788, 238);
            this.themsp.Name = "themsp";
            this.themsp.OnHoverBorderColor = System.Drawing.Color.Black;
            this.themsp.OnHoverButtonColor = System.Drawing.Color.Black;
            this.themsp.OnHoverTextColor = System.Drawing.Color.White;
            this.themsp.Size = new System.Drawing.Size(58, 38);
            this.themsp.TabIndex = 193;
            this.themsp.TextColor = System.Drawing.Color.Black;
            this.themsp.UseVisualStyleBackColor = false;
            this.themsp.Click += new System.EventHandler(this.themsp_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaDV,
            this.TenDV,
            this.DonGiaDV,
            this.SoLuongDV,
            this.ThanhTien,
            this.TraTruoc,
            this.ConLai,
            this.NgayGiao,
            this.TinhTrang});
            this.dataGridView2.Location = new System.Drawing.Point(31, 337);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(945, 225);
            this.dataGridView2.TabIndex = 192;
            // 
            // MaDV
            // 
            this.MaDV.HeaderText = "MaDV";
            this.MaDV.Name = "MaDV";
            // 
            // TenDV
            // 
            this.TenDV.HeaderText = "TenDV";
            this.TenDV.Name = "TenDV";
            // 
            // DonGiaDV
            // 
            this.DonGiaDV.HeaderText = "DonGiaDV";
            this.DonGiaDV.Name = "DonGiaDV";
            // 
            // SoLuongDV
            // 
            this.SoLuongDV.HeaderText = "SoLuongDV";
            this.SoLuongDV.Name = "SoLuongDV";
            // 
            // ThanhTien
            // 
            this.ThanhTien.HeaderText = "ThanhTien";
            this.ThanhTien.Name = "ThanhTien";
            // 
            // TraTruoc
            // 
            this.TraTruoc.HeaderText = "TraTruoc";
            this.TraTruoc.Name = "TraTruoc";
            // 
            // ConLai
            // 
            this.ConLai.HeaderText = "ConLai";
            this.ConLai.Name = "ConLai";
            // 
            // NgayGiao
            // 
            this.NgayGiao.HeaderText = "NgayGiao";
            this.NgayGiao.Name = "NgayGiao";
            // 
            // TinhTrang
            // 
            this.TinhTrang.HeaderText = "TinhTrang";
            this.TinhTrang.Name = "TinhTrang";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(370, 206);
            this.dataGridView1.TabIndex = 191;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(607, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 19);
            this.label2.TabIndex = 214;
            this.label2.Text = "Ngày giao:";
            // 
            // txtngaygiao
            // 
            this.txtngaygiao.BackColor = System.Drawing.Color.Transparent;
            this.txtngaygiao.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtngaygiao.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtngaygiao.ForeColors = System.Drawing.Color.Black;
            this.txtngaygiao.HintText = null;
            this.txtngaygiao.IsPassword = false;
            this.txtngaygiao.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtngaygiao.LineThickness = 2;
            this.txtngaygiao.Location = new System.Drawing.Point(611, 116);
            this.txtngaygiao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtngaygiao.MaxLength = 32767;
            this.txtngaygiao.Name = "txtngaygiao";
            this.txtngaygiao.OnFocusedColor = System.Drawing.Color.Black;
            this.txtngaygiao.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtngaygiao.ReadOnly = false;
            this.txtngaygiao.Size = new System.Drawing.Size(151, 23);
            this.txtngaygiao.TabIndex = 213;
            this.txtngaygiao.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtngaygiao.TextName = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(455, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 19);
            this.label3.TabIndex = 216;
            this.label3.Text = "Tình trạng:";
            // 
            // txttinhtrang
            // 
            this.txttinhtrang.BackColor = System.Drawing.Color.Transparent;
            this.txttinhtrang.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttinhtrang.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttinhtrang.ForeColors = System.Drawing.Color.Black;
            this.txttinhtrang.HintText = null;
            this.txttinhtrang.IsPassword = false;
            this.txttinhtrang.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txttinhtrang.LineThickness = 2;
            this.txttinhtrang.Location = new System.Drawing.Point(459, 195);
            this.txttinhtrang.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttinhtrang.MaxLength = 32767;
            this.txttinhtrang.Name = "txttinhtrang";
            this.txttinhtrang.OnFocusedColor = System.Drawing.Color.Black;
            this.txttinhtrang.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txttinhtrang.ReadOnly = false;
            this.txttinhtrang.Size = new System.Drawing.Size(115, 23);
            this.txttinhtrang.TabIndex = 215;
            this.txttinhtrang.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txttinhtrang.TextName = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(604, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 19);
            this.label7.TabIndex = 218;
            this.label7.Text = "Đơn giá được tính:";
            // 
            // txtdongia
            // 
            this.txtdongia.BackColor = System.Drawing.Color.Transparent;
            this.txtdongia.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtdongia.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtdongia.ForeColors = System.Drawing.Color.Black;
            this.txtdongia.HintText = null;
            this.txtdongia.IsPassword = false;
            this.txtdongia.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtdongia.LineThickness = 2;
            this.txtdongia.Location = new System.Drawing.Point(608, 195);
            this.txtdongia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtdongia.MaxLength = 32767;
            this.txtdongia.Name = "txtdongia";
            this.txtdongia.OnFocusedColor = System.Drawing.Color.Black;
            this.txtdongia.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtdongia.ReadOnly = false;
            this.txtdongia.Size = new System.Drawing.Size(154, 23);
            this.txtdongia.TabIndex = 217;
            this.txtdongia.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtdongia.TextName = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(455, 251);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 19);
            this.label8.TabIndex = 220;
            this.label8.Text = "Trả trước:";
            // 
            // txttratruoc
            // 
            this.txttratruoc.BackColor = System.Drawing.Color.Transparent;
            this.txttratruoc.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttratruoc.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txttratruoc.ForeColors = System.Drawing.Color.Black;
            this.txttratruoc.HintText = null;
            this.txttratruoc.IsPassword = false;
            this.txttratruoc.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txttratruoc.LineThickness = 2;
            this.txttratruoc.Location = new System.Drawing.Point(608, 247);
            this.txttratruoc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttratruoc.MaxLength = 32767;
            this.txttratruoc.Name = "txttratruoc";
            this.txttratruoc.OnFocusedColor = System.Drawing.Color.Black;
            this.txttratruoc.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txttratruoc.ReadOnly = false;
            this.txttratruoc.Size = new System.Drawing.Size(154, 23);
            this.txttratruoc.TabIndex = 219;
            this.txttratruoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txttratruoc.TextName = "";
            // 
            // sdt
            // 
            this.sdt.BackColor = System.Drawing.Color.Transparent;
            this.sdt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.ForeColors = System.Drawing.Color.Transparent;
            this.sdt.HintText = null;
            this.sdt.IsPassword = false;
            this.sdt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sdt.LineThickness = 2;
            this.sdt.Location = new System.Drawing.Point(12, 398);
            this.sdt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sdt.MaxLength = 32767;
            this.sdt.Name = "sdt";
            this.sdt.OnFocusedColor = System.Drawing.Color.Black;
            this.sdt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.sdt.ReadOnly = false;
            this.sdt.Size = new System.Drawing.Size(10, 10);
            this.sdt.TabIndex = 222;
            this.sdt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sdt.TextName = "";
            // 
            // TenKH
            // 
            this.TenKH.BackColor = System.Drawing.Color.Transparent;
            this.TenKH.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenKH.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenKH.ForeColors = System.Drawing.Color.Transparent;
            this.TenKH.HintText = null;
            this.TenKH.IsPassword = false;
            this.TenKH.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TenKH.LineThickness = 2;
            this.TenKH.Location = new System.Drawing.Point(12, 380);
            this.TenKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TenKH.MaxLength = 32767;
            this.TenKH.Name = "TenKH";
            this.TenKH.OnFocusedColor = System.Drawing.Color.Black;
            this.TenKH.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TenKH.ReadOnly = false;
            this.TenKH.Size = new System.Drawing.Size(10, 10);
            this.TenKH.TabIndex = 221;
            this.TenKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TenKH.TextName = "";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(884, 19);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 225;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(805, 246);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 224;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(805, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 223;
            this.pictureBox1.TabStop = false;
            // 
            // NV_6Dichvu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.sdt);
            this.Controls.Add(this.TenKH);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txttratruoc);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtdongia);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txttinhtrang);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtngaygiao);
            this.Controls.Add(this.timkiem);
            this.Controls.Add(this.TraCuu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LoaiTimKiem);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.MaPDV);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtuser);
            this.Controls.Add(this.MaKH);
            this.Controls.Add(this.lammoi);
            this.Controls.Add(this.tieptuc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SLsanpham);
            this.Controls.Add(this.themsp);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "NV_6Dichvu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chọn Dịch Vụ";
            this.Load += new System.EventHandler(this.NV_6Dichvu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC timkiem;
        private JMaterialTextbox.JMaterialTextbox TraCuu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox LoaiTimKiem;
        private System.Windows.Forms.Label label6;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private JMaterialTextbox.JMaterialTextbox MaPDV;
        private JMaterialTextbox.JMaterialTextbox txtpass;
        private JMaterialTextbox.JMaterialTextbox txtuser;
        private JMaterialTextbox.JMaterialTextbox MaKH;
        private ePOSOne.btnProduct.Button_WOC lammoi;
        private ePOSOne.btnProduct.Button_WOC tieptuc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private JMaterialTextbox.JMaterialTextbox SLsanpham;
        private ePOSOne.btnProduct.Button_WOC themsp;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private JMaterialTextbox.JMaterialTextbox txtngaygiao;
        private System.Windows.Forms.Label label3;
        private JMaterialTextbox.JMaterialTextbox txttinhtrang;
        private System.Windows.Forms.Label label7;
        private JMaterialTextbox.JMaterialTextbox txtdongia;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGiaDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn ThanhTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TraTruoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConLai;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayGiao;
        private System.Windows.Forms.DataGridViewTextBoxColumn TinhTrang;
        private System.Windows.Forms.Label label8;
        private JMaterialTextbox.JMaterialTextbox txttratruoc;
        private JMaterialTextbox.JMaterialTextbox sdt;
        private JMaterialTextbox.JMaterialTextbox TenKH;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}