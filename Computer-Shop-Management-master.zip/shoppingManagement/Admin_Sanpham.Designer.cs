﻿namespace shoppingManagement
{
    partial class Admin_Sanpham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Sanpham));
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MaVL = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MaSP = new JMaterialTextbox.JMaterialTextbox();
            this.MaDT = new JMaterialTextbox.JMaterialTextbox();
            this.TenSP = new JMaterialTextbox.JMaterialTextbox();
            this.DonGia = new JMaterialTextbox.JMaterialTextbox();
            this.SLTon = new JMaterialTextbox.JMaterialTextbox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.TraCuu = new JMaterialTextbox.JMaterialTextbox();
            this.timkiem = new ePOSOne.btnProduct.Button_WOC();
            this.lammoi = new ePOSOne.btnProduct.Button_WOC();
            this.capnhatsanpham = new ePOSOne.btnProduct.Button_WOC();
            this.xoasanpham = new ePOSOne.btnProduct.Button_WOC();
            this.themsanpham = new ePOSOne.btnProduct.Button_WOC();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.label12 = new System.Windows.Forms.Label();
            this.DVT = new System.Windows.Forms.ComboBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(428, 399);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(224, 194);
            this.dataGridView2.TabIndex = 50;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(25, 398);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 19);
            this.label10.TabIndex = 46;
            this.label10.Text = "Số lượng tồn:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 338);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 19);
            this.label9.TabIndex = 45;
            this.label9.Text = "Đơn giá:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 278);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 19);
            this.label8.TabIndex = 44;
            this.label8.Text = "Tên sản phẩm:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 19);
            this.label7.TabIndex = 43;
            this.label7.Text = "Loại sản phẩm:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 19);
            this.label3.TabIndex = 41;
            this.label3.Text = "Mã sản phẩm:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(428, 93);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(562, 243);
            this.dataGridView1.TabIndex = 38;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // MaVL
            // 
            this.MaVL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MaVL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MaVL.FormattingEnabled = true;
            this.MaVL.Items.AddRange(new object[] {
            "VL01",
            "VL02",
            "VL03",
            "VL04",
            "VL05",
            "VL06",
            "VL07",
            "VL08",
            "VL09",
            "VL10"});
            this.MaVL.Location = new System.Drawing.Point(164, 128);
            this.MaVL.Name = "MaVL";
            this.MaVL.Size = new System.Drawing.Size(171, 21);
            this.MaVL.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 19);
            this.label1.TabIndex = 56;
            this.label1.Text = "Mã đối tác:";
            // 
            // MaSP
            // 
            this.MaSP.BackColor = System.Drawing.Color.Transparent;
            this.MaSP.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaSP.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaSP.ForeColors = System.Drawing.Color.Black;
            this.MaSP.HintText = null;
            this.MaSP.IsPassword = false;
            this.MaSP.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaSP.LineThickness = 2;
            this.MaSP.Location = new System.Drawing.Point(164, 70);
            this.MaSP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaSP.MaxLength = 32767;
            this.MaSP.Name = "MaSP";
            this.MaSP.OnFocusedColor = System.Drawing.Color.Black;
            this.MaSP.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaSP.ReadOnly = false;
            this.MaSP.Size = new System.Drawing.Size(171, 23);
            this.MaSP.TabIndex = 57;
            this.MaSP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaSP.TextName = "";
            // 
            // MaDT
            // 
            this.MaDT.BackColor = System.Drawing.Color.Transparent;
            this.MaDT.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaDT.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaDT.ForeColors = System.Drawing.Color.Black;
            this.MaDT.HintText = null;
            this.MaDT.IsPassword = false;
            this.MaDT.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaDT.LineThickness = 2;
            this.MaDT.Location = new System.Drawing.Point(164, 222);
            this.MaDT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaDT.MaxLength = 32767;
            this.MaDT.Name = "MaDT";
            this.MaDT.OnFocusedColor = System.Drawing.Color.Black;
            this.MaDT.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaDT.ReadOnly = false;
            this.MaDT.Size = new System.Drawing.Size(171, 18);
            this.MaDT.TabIndex = 58;
            this.MaDT.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaDT.TextName = "";
            // 
            // TenSP
            // 
            this.TenSP.BackColor = System.Drawing.Color.Transparent;
            this.TenSP.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenSP.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenSP.ForeColors = System.Drawing.Color.Black;
            this.TenSP.HintText = null;
            this.TenSP.IsPassword = false;
            this.TenSP.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TenSP.LineThickness = 2;
            this.TenSP.Location = new System.Drawing.Point(164, 278);
            this.TenSP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TenSP.MaxLength = 32767;
            this.TenSP.Name = "TenSP";
            this.TenSP.OnFocusedColor = System.Drawing.Color.Black;
            this.TenSP.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TenSP.ReadOnly = false;
            this.TenSP.Size = new System.Drawing.Size(171, 18);
            this.TenSP.TabIndex = 59;
            this.TenSP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TenSP.TextName = "";
            // 
            // DonGia
            // 
            this.DonGia.BackColor = System.Drawing.Color.Transparent;
            this.DonGia.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DonGia.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DonGia.ForeColors = System.Drawing.Color.Black;
            this.DonGia.HintText = null;
            this.DonGia.IsPassword = false;
            this.DonGia.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DonGia.LineThickness = 2;
            this.DonGia.Location = new System.Drawing.Point(164, 339);
            this.DonGia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DonGia.MaxLength = 32767;
            this.DonGia.Name = "DonGia";
            this.DonGia.OnFocusedColor = System.Drawing.Color.Black;
            this.DonGia.OnFocusedTextColor = System.Drawing.Color.Black;
            this.DonGia.ReadOnly = false;
            this.DonGia.Size = new System.Drawing.Size(171, 18);
            this.DonGia.TabIndex = 60;
            this.DonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.DonGia.TextName = "";
            // 
            // SLTon
            // 
            this.SLTon.BackColor = System.Drawing.Color.Transparent;
            this.SLTon.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.SLTon.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.SLTon.ForeColors = System.Drawing.Color.Black;
            this.SLTon.HintText = null;
            this.SLTon.IsPassword = false;
            this.SLTon.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SLTon.LineThickness = 2;
            this.SLTon.Location = new System.Drawing.Point(164, 399);
            this.SLTon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SLTon.MaxLength = 32767;
            this.SLTon.Name = "SLTon";
            this.SLTon.OnFocusedColor = System.Drawing.Color.Black;
            this.SLTon.OnFocusedTextColor = System.Drawing.Color.Black;
            this.SLTon.ReadOnly = false;
            this.SLTon.Size = new System.Drawing.Size(171, 18);
            this.SLTon.TabIndex = 61;
            this.SLTon.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.SLTon.TextName = "";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(672, 399);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(318, 194);
            this.dataGridView3.TabIndex = 62;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(424, 367);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 19);
            this.label2.TabIndex = 63;
            this.label2.Text = "Bảng vật liệu:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(668, 367);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 19);
            this.label4.TabIndex = 64;
            this.label4.Text = "Danh sách đối tác:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(424, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 19);
            this.label5.TabIndex = 65;
            this.label5.Text = "Bảng sản phẩm:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(160, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 19);
            this.label6.TabIndex = 66;
            this.label6.Text = "Tìm kiếm theo:";
            // 
            // LoaiTimKiem
            // 
            this.LoaiTimKiem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaiTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaiTimKiem.FormattingEnabled = true;
            this.LoaiTimKiem.Items.AddRange(new object[] {
            "MaSP",
            "MaVL",
            "MaDT"});
            this.LoaiTimKiem.Location = new System.Drawing.Point(287, 25);
            this.LoaiTimKiem.Name = "LoaiTimKiem";
            this.LoaiTimKiem.Size = new System.Drawing.Size(92, 21);
            this.LoaiTimKiem.TabIndex = 67;
            this.LoaiTimKiem.SelectedIndexChanged += new System.EventHandler(this.LoaiTimKiem_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(424, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 19);
            this.label11.TabIndex = 68;
            this.label11.Text = "Nhập từ khóa:";
            // 
            // TraCuu
            // 
            this.TraCuu.BackColor = System.Drawing.Color.Transparent;
            this.TraCuu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.ForeColors = System.Drawing.Color.Black;
            this.TraCuu.HintText = null;
            this.TraCuu.IsPassword = false;
            this.TraCuu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TraCuu.LineThickness = 2;
            this.TraCuu.Location = new System.Drawing.Point(551, 23);
            this.TraCuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TraCuu.MaxLength = 32767;
            this.TraCuu.Name = "TraCuu";
            this.TraCuu.OnFocusedColor = System.Drawing.Color.Black;
            this.TraCuu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TraCuu.ReadOnly = false;
            this.TraCuu.Size = new System.Drawing.Size(255, 23);
            this.TraCuu.TabIndex = 69;
            this.TraCuu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TraCuu.TextName = "";
            // 
            // timkiem
            // 
            this.timkiem.BackColor = System.Drawing.Color.White;
            this.timkiem.BorderColor = System.Drawing.Color.Black;
            this.timkiem.ButtonColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderSize = 0;
            this.timkiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timkiem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timkiem.Location = new System.Drawing.Point(830, 21);
            this.timkiem.Name = "timkiem";
            this.timkiem.OnHoverBorderColor = System.Drawing.Color.Black;
            this.timkiem.OnHoverButtonColor = System.Drawing.Color.White;
            this.timkiem.OnHoverTextColor = System.Drawing.Color.Black;
            this.timkiem.Size = new System.Drawing.Size(58, 38);
            this.timkiem.TabIndex = 70;
            this.timkiem.Text = " ";
            this.timkiem.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.UseVisualStyleBackColor = false;
            this.timkiem.Click += new System.EventHandler(this.timkiem_Click);
            // 
            // lammoi
            // 
            this.lammoi.BorderColor = System.Drawing.Color.Black;
            this.lammoi.ButtonColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderSize = 0;
            this.lammoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.lammoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lammoi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lammoi.Location = new System.Drawing.Point(906, 21);
            this.lammoi.Name = "lammoi";
            this.lammoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverButtonColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverTextColor = System.Drawing.Color.White;
            this.lammoi.Size = new System.Drawing.Size(58, 38);
            this.lammoi.TabIndex = 51;
            this.lammoi.Text = " ";
            this.lammoi.TextColor = System.Drawing.Color.Black;
            this.lammoi.UseVisualStyleBackColor = true;
            this.lammoi.Click += new System.EventHandler(this.lammoi_Click);
            // 
            // capnhatsanpham
            // 
            this.capnhatsanpham.BorderColor = System.Drawing.Color.Black;
            this.capnhatsanpham.ButtonColor = System.Drawing.Color.White;
            this.capnhatsanpham.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.capnhatsanpham.FlatAppearance.BorderSize = 0;
            this.capnhatsanpham.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.capnhatsanpham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.capnhatsanpham.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capnhatsanpham.Location = new System.Drawing.Point(152, 464);
            this.capnhatsanpham.Name = "capnhatsanpham";
            this.capnhatsanpham.OnHoverBorderColor = System.Drawing.Color.Black;
            this.capnhatsanpham.OnHoverButtonColor = System.Drawing.Color.White;
            this.capnhatsanpham.OnHoverTextColor = System.Drawing.Color.Black;
            this.capnhatsanpham.Size = new System.Drawing.Size(58, 38);
            this.capnhatsanpham.TabIndex = 49;
            this.capnhatsanpham.Text = " ";
            this.capnhatsanpham.TextColor = System.Drawing.Color.White;
            this.capnhatsanpham.UseVisualStyleBackColor = true;
            this.capnhatsanpham.Click += new System.EventHandler(this.capnhatsanpham_Click);
            // 
            // xoasanpham
            // 
            this.xoasanpham.BorderColor = System.Drawing.Color.Black;
            this.xoasanpham.ButtonColor = System.Drawing.Color.White;
            this.xoasanpham.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.xoasanpham.FlatAppearance.BorderSize = 0;
            this.xoasanpham.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.xoasanpham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xoasanpham.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xoasanpham.Location = new System.Drawing.Point(245, 464);
            this.xoasanpham.Name = "xoasanpham";
            this.xoasanpham.OnHoverBorderColor = System.Drawing.Color.Black;
            this.xoasanpham.OnHoverButtonColor = System.Drawing.Color.White;
            this.xoasanpham.OnHoverTextColor = System.Drawing.Color.Black;
            this.xoasanpham.Size = new System.Drawing.Size(58, 38);
            this.xoasanpham.TabIndex = 48;
            this.xoasanpham.Text = " ";
            this.xoasanpham.TextColor = System.Drawing.Color.White;
            this.xoasanpham.UseVisualStyleBackColor = true;
            this.xoasanpham.Click += new System.EventHandler(this.xoasanpham_Click);
            // 
            // themsanpham
            // 
            this.themsanpham.BorderColor = System.Drawing.Color.Black;
            this.themsanpham.ButtonColor = System.Drawing.Color.White;
            this.themsanpham.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.themsanpham.FlatAppearance.BorderSize = 0;
            this.themsanpham.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.themsanpham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.themsanpham.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.themsanpham.Location = new System.Drawing.Point(59, 464);
            this.themsanpham.Name = "themsanpham";
            this.themsanpham.OnHoverBorderColor = System.Drawing.Color.Black;
            this.themsanpham.OnHoverButtonColor = System.Drawing.Color.White;
            this.themsanpham.OnHoverTextColor = System.Drawing.Color.Black;
            this.themsanpham.Size = new System.Drawing.Size(58, 38);
            this.themsanpham.TabIndex = 47;
            this.themsanpham.Text = " ";
            this.themsanpham.TextColor = System.Drawing.Color.White;
            this.themsanpham.UseVisualStyleBackColor = true;
            this.themsanpham.Click += new System.EventHandler(this.themsanpham_Click);
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(22, 14);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 42;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(25, 178);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 19);
            this.label12.TabIndex = 71;
            this.label12.Text = "Đơn vị tính";
            // 
            // DVT
            // 
            this.DVT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DVT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DVT.FormattingEnabled = true;
            this.DVT.Items.AddRange(new object[] {
            "Cái",
            "Viên"});
            this.DVT.Location = new System.Drawing.Point(164, 176);
            this.DVT.Name = "DVT";
            this.DVT.Size = new System.Drawing.Size(171, 21);
            this.DVT.TabIndex = 72;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(925, 29);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 142;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(169, 472);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(23, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 141;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(264, 472);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(23, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 140;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(76, 472);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 139;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(848, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 138;
            this.pictureBox1.TabStop = false;
            // 
            // Admin_Sanpham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.DVT);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.timkiem);
            this.Controls.Add(this.TraCuu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LoaiTimKiem);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.SLTon);
            this.Controls.Add(this.DonGia);
            this.Controls.Add(this.TenSP);
            this.Controls.Add(this.MaDT);
            this.Controls.Add(this.MaSP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lammoi);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.capnhatsanpham);
            this.Controls.Add(this.xoasanpham);
            this.Controls.Add(this.themsanpham);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.MaVL);
            this.Name = "Admin_Sanpham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Sản Phẩm";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC lammoi;
        private System.Windows.Forms.DataGridView dataGridView2;
        private ePOSOne.btnProduct.Button_WOC capnhatsanpham;
        private ePOSOne.btnProduct.Button_WOC xoasanpham;
        private ePOSOne.btnProduct.Button_WOC themsanpham;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox MaVL;
        private System.Windows.Forms.Label label1;
        private JMaterialTextbox.JMaterialTextbox MaSP;
        private JMaterialTextbox.JMaterialTextbox MaDT;
        private JMaterialTextbox.JMaterialTextbox TenSP;
        private JMaterialTextbox.JMaterialTextbox DonGia;
        private JMaterialTextbox.JMaterialTextbox SLTon;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox LoaiTimKiem;
        private System.Windows.Forms.Label label11;
        private JMaterialTextbox.JMaterialTextbox TraCuu;
        private ePOSOne.btnProduct.Button_WOC timkiem;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox DVT;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}