﻿
namespace shoppingManagement
{
    partial class NV_4Khachhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NV_4Khachhang));
            this.tieptuc = new ePOSOne.btnProduct.Button_WOC();
            this.passtxt = new JMaterialTextbox.JMaterialTextbox();
            this.usertxt = new JMaterialTextbox.JMaterialTextbox();
            this.Loai = new System.Windows.Forms.ComboBox();
            this.dSinh = new JMaterialTextbox.JMaterialTextbox();
            this.sdt = new JMaterialTextbox.JMaterialTextbox();
            this.label16 = new System.Windows.Forms.Label();
            this.Diem = new JMaterialTextbox.JMaterialTextbox();
            this.label15 = new System.Windows.Forms.Label();
            this.GioiTinh = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timkiem = new ePOSOne.btnProduct.Button_WOC();
            this.TraCuu = new JMaterialTextbox.JMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.LoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Email = new JMaterialTextbox.JMaterialTextbox();
            this.TenKH = new JMaterialTextbox.JMaterialTextbox();
            this.MaKH = new JMaterialTextbox.JMaterialTextbox();
            this.lammoi = new ePOSOne.btnProduct.Button_WOC();
            this.capnhat = new ePOSOne.btnProduct.Button_WOC();
            this.xoa = new ePOSOne.btnProduct.Button_WOC();
            this.them = new ePOSOne.btnProduct.Button_WOC();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tieptuc
            // 
            this.tieptuc.BorderColor = System.Drawing.Color.Black;
            this.tieptuc.ButtonColor = System.Drawing.Color.White;
            this.tieptuc.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.tieptuc.FlatAppearance.BorderSize = 0;
            this.tieptuc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.tieptuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tieptuc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tieptuc.Location = new System.Drawing.Point(831, 221);
            this.tieptuc.Name = "tieptuc";
            this.tieptuc.OnHoverBorderColor = System.Drawing.Color.Black;
            this.tieptuc.OnHoverButtonColor = System.Drawing.Color.Black;
            this.tieptuc.OnHoverTextColor = System.Drawing.Color.White;
            this.tieptuc.Size = new System.Drawing.Size(103, 39);
            this.tieptuc.TabIndex = 211;
            this.tieptuc.Text = "Tiếp Tục";
            this.tieptuc.TextColor = System.Drawing.Color.Black;
            this.tieptuc.UseVisualStyleBackColor = true;
            this.tieptuc.Click += new System.EventHandler(this.tieptuc_Click);
            // 
            // passtxt
            // 
            this.passtxt.BackColor = System.Drawing.Color.Transparent;
            this.passtxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passtxt.ForeColors = System.Drawing.Color.Transparent;
            this.passtxt.HintText = null;
            this.passtxt.IsPassword = false;
            this.passtxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.passtxt.LineThickness = 2;
            this.passtxt.Location = new System.Drawing.Point(992, 150);
            this.passtxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passtxt.MaxLength = 32767;
            this.passtxt.Name = "passtxt";
            this.passtxt.OnFocusedColor = System.Drawing.Color.Black;
            this.passtxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.passtxt.ReadOnly = false;
            this.passtxt.Size = new System.Drawing.Size(10, 10);
            this.passtxt.TabIndex = 210;
            this.passtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passtxt.TextName = "";
            // 
            // usertxt
            // 
            this.usertxt.BackColor = System.Drawing.Color.Transparent;
            this.usertxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usertxt.ForeColors = System.Drawing.Color.Transparent;
            this.usertxt.HintText = null;
            this.usertxt.IsPassword = false;
            this.usertxt.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.usertxt.LineThickness = 2;
            this.usertxt.Location = new System.Drawing.Point(992, 132);
            this.usertxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usertxt.MaxLength = 32767;
            this.usertxt.Name = "usertxt";
            this.usertxt.OnFocusedColor = System.Drawing.Color.Black;
            this.usertxt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.usertxt.ReadOnly = false;
            this.usertxt.Size = new System.Drawing.Size(10, 10);
            this.usertxt.TabIndex = 209;
            this.usertxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.usertxt.TextName = "";
            // 
            // Loai
            // 
            this.Loai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Loai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Loai.FormattingEnabled = true;
            this.Loai.Items.AddRange(new object[] {
            "VIP",
            "Thuong"});
            this.Loai.Location = new System.Drawing.Point(806, 106);
            this.Loai.Name = "Loai";
            this.Loai.Size = new System.Drawing.Size(92, 21);
            this.Loai.TabIndex = 208;
            // 
            // dSinh
            // 
            this.dSinh.BackColor = System.Drawing.Color.Transparent;
            this.dSinh.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dSinh.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dSinh.ForeColors = System.Drawing.Color.Black;
            this.dSinh.HintText = null;
            this.dSinh.IsPassword = false;
            this.dSinh.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dSinh.LineThickness = 2;
            this.dSinh.Location = new System.Drawing.Point(127, 161);
            this.dSinh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dSinh.MaxLength = 32767;
            this.dSinh.Name = "dSinh";
            this.dSinh.OnFocusedColor = System.Drawing.Color.Black;
            this.dSinh.OnFocusedTextColor = System.Drawing.Color.Black;
            this.dSinh.ReadOnly = false;
            this.dSinh.Size = new System.Drawing.Size(160, 23);
            this.dSinh.TabIndex = 207;
            this.dSinh.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dSinh.TextName = "";
            // 
            // sdt
            // 
            this.sdt.BackColor = System.Drawing.Color.Transparent;
            this.sdt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.sdt.ForeColors = System.Drawing.Color.Black;
            this.sdt.HintText = null;
            this.sdt.IsPassword = false;
            this.sdt.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sdt.LineThickness = 2;
            this.sdt.Location = new System.Drawing.Point(558, 165);
            this.sdt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sdt.MaxLength = 32767;
            this.sdt.Name = "sdt";
            this.sdt.OnFocusedColor = System.Drawing.Color.Black;
            this.sdt.OnFocusedTextColor = System.Drawing.Color.Black;
            this.sdt.ReadOnly = false;
            this.sdt.Size = new System.Drawing.Size(158, 18);
            this.sdt.TabIndex = 206;
            this.sdt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sdt.TextName = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(505, 165);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 19);
            this.label16.TabIndex = 205;
            this.label16.Text = "SĐT:";
            // 
            // Diem
            // 
            this.Diem.BackColor = System.Drawing.Color.Transparent;
            this.Diem.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Diem.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Diem.ForeColors = System.Drawing.Color.Black;
            this.Diem.HintText = null;
            this.Diem.IsPassword = false;
            this.Diem.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Diem.LineThickness = 2;
            this.Diem.Location = new System.Drawing.Point(821, 165);
            this.Diem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Diem.MaxLength = 32767;
            this.Diem.Name = "Diem";
            this.Diem.OnFocusedColor = System.Drawing.Color.Black;
            this.Diem.OnFocusedTextColor = System.Drawing.Color.Black;
            this.Diem.ReadOnly = false;
            this.Diem.Size = new System.Drawing.Size(61, 18);
            this.Diem.TabIndex = 204;
            this.Diem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Diem.TextName = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(747, 165);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 19);
            this.label15.TabIndex = 203;
            this.label15.Text = "Điểm:";
            // 
            // GioiTinh
            // 
            this.GioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GioiTinh.FormattingEnabled = true;
            this.GioiTinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khac"});
            this.GioiTinh.Location = new System.Drawing.Point(390, 163);
            this.GioiTinh.Name = "GioiTinh";
            this.GioiTinh.Size = new System.Drawing.Size(92, 21);
            this.GioiTinh.TabIndex = 202;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(18, 165);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 19);
            this.label14.TabIndex = 201;
            this.label14.Text = "Ngày sinh:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(747, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 19);
            this.label2.TabIndex = 200;
            this.label2.Text = "Loại: ";
            // 
            // timkiem
            // 
            this.timkiem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.BorderColor = System.Drawing.Color.Black;
            this.timkiem.ButtonColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.timkiem.FlatAppearance.BorderSize = 0;
            this.timkiem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.timkiem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timkiem.Location = new System.Drawing.Point(788, 29);
            this.timkiem.Name = "timkiem";
            this.timkiem.OnHoverBorderColor = System.Drawing.Color.Black;
            this.timkiem.OnHoverButtonColor = System.Drawing.Color.White;
            this.timkiem.OnHoverTextColor = System.Drawing.Color.Black;
            this.timkiem.Size = new System.Drawing.Size(58, 38);
            this.timkiem.TabIndex = 199;
            this.timkiem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.timkiem.TextColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timkiem.UseVisualStyleBackColor = false;
            this.timkiem.Click += new System.EventHandler(this.timkiem_Click);
            // 
            // TraCuu
            // 
            this.TraCuu.BackColor = System.Drawing.Color.Transparent;
            this.TraCuu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TraCuu.ForeColors = System.Drawing.Color.Black;
            this.TraCuu.HintText = null;
            this.TraCuu.IsPassword = false;
            this.TraCuu.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TraCuu.LineThickness = 2;
            this.TraCuu.Location = new System.Drawing.Point(509, 31);
            this.TraCuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TraCuu.MaxLength = 32767;
            this.TraCuu.Name = "TraCuu";
            this.TraCuu.OnFocusedColor = System.Drawing.Color.Black;
            this.TraCuu.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TraCuu.ReadOnly = false;
            this.TraCuu.Size = new System.Drawing.Size(255, 23);
            this.TraCuu.TabIndex = 198;
            this.TraCuu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TraCuu.TextName = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(382, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 19);
            this.label11.TabIndex = 197;
            this.label11.Text = "Nhập từ khóa:";
            // 
            // LoaiTimKiem
            // 
            this.LoaiTimKiem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaiTimKiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaiTimKiem.FormattingEnabled = true;
            this.LoaiTimKiem.Items.AddRange(new object[] {
            "TenKH",
            "MaKH",
            "SDT"});
            this.LoaiTimKiem.Location = new System.Drawing.Point(280, 31);
            this.LoaiTimKiem.Name = "LoaiTimKiem";
            this.LoaiTimKiem.Size = new System.Drawing.Size(92, 21);
            this.LoaiTimKiem.TabIndex = 196;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(153, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 19);
            this.label6.TabIndex = 195;
            this.label6.Text = "Tìm kiếm theo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 19);
            this.label5.TabIndex = 194;
            this.label5.Text = "Bảng khách hàng:";
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.Color.Transparent;
            this.Email.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Email.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Email.ForeColors = System.Drawing.Color.Black;
            this.Email.HintText = null;
            this.Email.IsPassword = false;
            this.Email.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Email.LineThickness = 2;
            this.Email.Location = new System.Drawing.Point(101, 221);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Email.MaxLength = 32767;
            this.Email.Name = "Email";
            this.Email.OnFocusedColor = System.Drawing.Color.Black;
            this.Email.OnFocusedTextColor = System.Drawing.Color.Black;
            this.Email.ReadOnly = false;
            this.Email.Size = new System.Drawing.Size(186, 18);
            this.Email.TabIndex = 193;
            this.Email.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Email.TextName = "";
            // 
            // TenKH
            // 
            this.TenKH.BackColor = System.Drawing.Color.Transparent;
            this.TenKH.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenKH.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.TenKH.ForeColors = System.Drawing.Color.Black;
            this.TenKH.HintText = null;
            this.TenKH.IsPassword = false;
            this.TenKH.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TenKH.LineThickness = 2;
            this.TenKH.Location = new System.Drawing.Point(433, 108);
            this.TenKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TenKH.MaxLength = 32767;
            this.TenKH.Name = "TenKH";
            this.TenKH.OnFocusedColor = System.Drawing.Color.Black;
            this.TenKH.OnFocusedTextColor = System.Drawing.Color.Black;
            this.TenKH.ReadOnly = false;
            this.TenKH.Size = new System.Drawing.Size(283, 18);
            this.TenKH.TabIndex = 192;
            this.TenKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TenKH.TextName = "";
            // 
            // MaKH
            // 
            this.MaKH.BackColor = System.Drawing.Color.Transparent;
            this.MaKH.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.ForeColors = System.Drawing.Color.Black;
            this.MaKH.HintText = null;
            this.MaKH.IsPassword = false;
            this.MaKH.LineBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaKH.LineThickness = 2;
            this.MaKH.Location = new System.Drawing.Point(160, 104);
            this.MaKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaKH.MaxLength = 32767;
            this.MaKH.Name = "MaKH";
            this.MaKH.OnFocusedColor = System.Drawing.Color.Black;
            this.MaKH.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaKH.ReadOnly = false;
            this.MaKH.Size = new System.Drawing.Size(127, 23);
            this.MaKH.TabIndex = 191;
            this.MaKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaKH.TextName = "";
            // 
            // lammoi
            // 
            this.lammoi.BorderColor = System.Drawing.Color.Black;
            this.lammoi.ButtonColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.lammoi.FlatAppearance.BorderSize = 0;
            this.lammoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.lammoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lammoi.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lammoi.Location = new System.Drawing.Point(876, 29);
            this.lammoi.Name = "lammoi";
            this.lammoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverButtonColor = System.Drawing.Color.Black;
            this.lammoi.OnHoverTextColor = System.Drawing.Color.White;
            this.lammoi.Size = new System.Drawing.Size(58, 38);
            this.lammoi.TabIndex = 190;
            this.lammoi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lammoi.TextColor = System.Drawing.Color.Black;
            this.lammoi.UseVisualStyleBackColor = true;
            this.lammoi.Click += new System.EventHandler(this.lammoi_Click);
            // 
            // capnhat
            // 
            this.capnhat.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.capnhat.BorderColor = System.Drawing.Color.Black;
            this.capnhat.ButtonColor = System.Drawing.Color.White;
            this.capnhat.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.capnhat.FlatAppearance.BorderSize = 0;
            this.capnhat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.capnhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.capnhat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capnhat.Location = new System.Drawing.Point(652, 223);
            this.capnhat.Name = "capnhat";
            this.capnhat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.capnhat.OnHoverButtonColor = System.Drawing.Color.White;
            this.capnhat.OnHoverTextColor = System.Drawing.Color.Black;
            this.capnhat.Size = new System.Drawing.Size(58, 38);
            this.capnhat.TabIndex = 189;
            this.capnhat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.capnhat.TextColor = System.Drawing.Color.White;
            this.capnhat.UseVisualStyleBackColor = false;
            this.capnhat.Click += new System.EventHandler(this.capnhat_Click);
            // 
            // xoa
            // 
            this.xoa.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.xoa.BorderColor = System.Drawing.Color.Black;
            this.xoa.ButtonColor = System.Drawing.Color.White;
            this.xoa.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.xoa.FlatAppearance.BorderSize = 0;
            this.xoa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.xoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xoa.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xoa.Location = new System.Drawing.Point(743, 223);
            this.xoa.Name = "xoa";
            this.xoa.OnHoverBorderColor = System.Drawing.Color.Black;
            this.xoa.OnHoverButtonColor = System.Drawing.Color.White;
            this.xoa.OnHoverTextColor = System.Drawing.Color.Black;
            this.xoa.Size = new System.Drawing.Size(58, 38);
            this.xoa.TabIndex = 188;
            this.xoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.xoa.TextColor = System.Drawing.Color.White;
            this.xoa.UseVisualStyleBackColor = false;
            this.xoa.Click += new System.EventHandler(this.xoa_Click);
            // 
            // them
            // 
            this.them.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.them.BorderColor = System.Drawing.Color.Black;
            this.them.ButtonColor = System.Drawing.Color.White;
            this.them.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.them.FlatAppearance.BorderSize = 0;
            this.them.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.them.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.them.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.them.Location = new System.Drawing.Point(560, 223);
            this.them.Name = "them";
            this.them.OnHoverBorderColor = System.Drawing.Color.Black;
            this.them.OnHoverButtonColor = System.Drawing.Color.White;
            this.them.OnHoverTextColor = System.Drawing.Color.Black;
            this.them.Size = new System.Drawing.Size(58, 38);
            this.them.TabIndex = 187;
            this.them.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.them.TextColor = System.Drawing.Color.White;
            this.them.UseVisualStyleBackColor = false;
            this.them.Click += new System.EventHandler(this.them_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(294, 165);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 19);
            this.label10.TabIndex = 186;
            this.label10.Text = "Giới tính:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 220);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 19);
            this.label9.TabIndex = 185;
            this.label9.Text = "Email:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(294, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 19);
            this.label8.TabIndex = 184;
            this.label8.Text = "Tên khách hàng:";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(15, 20);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 183;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 19);
            this.label3.TabIndex = 182;
            this.label3.Text = "Mã khách hàng:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(101, 331);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(856, 312);
            this.dataGridView1.TabIndex = 181;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(895, 37);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 215;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(670, 231);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(23, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 214;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(761, 232);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(23, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 213;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(806, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 212;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(578, 232);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 216;
            this.pictureBox2.TabStop = false;
            // 
            // NV_4Khachhang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tieptuc);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.Loai);
            this.Controls.Add(this.dSinh);
            this.Controls.Add(this.sdt);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.Diem);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.GioiTinh);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.timkiem);
            this.Controls.Add(this.TraCuu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LoaiTimKiem);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.TenKH);
            this.Controls.Add(this.MaKH);
            this.Controls.Add(this.lammoi);
            this.Controls.Add(this.capnhat);
            this.Controls.Add(this.xoa);
            this.Controls.Add(this.them);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.quayve);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Name = "NV_4Khachhang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chọn Khách Hàng";
            this.Load += new System.EventHandler(this.NV_4Khachhang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC tieptuc;
        private JMaterialTextbox.JMaterialTextbox passtxt;
        private JMaterialTextbox.JMaterialTextbox usertxt;
        private System.Windows.Forms.ComboBox Loai;
        private JMaterialTextbox.JMaterialTextbox dSinh;
        private JMaterialTextbox.JMaterialTextbox sdt;
        private System.Windows.Forms.Label label16;
        private JMaterialTextbox.JMaterialTextbox Diem;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox GioiTinh;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private ePOSOne.btnProduct.Button_WOC timkiem;
        private JMaterialTextbox.JMaterialTextbox TraCuu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox LoaiTimKiem;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private JMaterialTextbox.JMaterialTextbox Email;
        private JMaterialTextbox.JMaterialTextbox TenKH;
        private JMaterialTextbox.JMaterialTextbox MaKH;
        private ePOSOne.btnProduct.Button_WOC lammoi;
        private ePOSOne.btnProduct.Button_WOC capnhat;
        private ePOSOne.btnProduct.Button_WOC xoa;
        private ePOSOne.btnProduct.Button_WOC them;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}