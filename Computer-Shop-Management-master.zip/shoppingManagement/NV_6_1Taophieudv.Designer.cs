﻿
namespace shoppingManagement
{
    partial class NV_6_1Taophieudv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MaHD = new JMaterialTextbox.JMaterialTextbox();
            this.txtpass = new JMaterialTextbox.JMaterialTextbox();
            this.txtuser = new JMaterialTextbox.JMaterialTextbox();
            this.MaKH = new JMaterialTextbox.JMaterialTextbox();
            this.quayve = new ePOSOne.btnProduct.Button_WOC();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // MaHD
            // 
            this.MaHD.BackColor = System.Drawing.Color.Transparent;
            this.MaHD.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaHD.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaHD.ForeColors = System.Drawing.Color.Transparent;
            this.MaHD.HintText = null;
            this.MaHD.IsPassword = false;
            this.MaHD.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MaHD.LineThickness = 2;
            this.MaHD.Location = new System.Drawing.Point(994, 42);
            this.MaHD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaHD.MaxLength = 32767;
            this.MaHD.Name = "MaHD";
            this.MaHD.OnFocusedColor = System.Drawing.Color.Black;
            this.MaHD.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaHD.ReadOnly = false;
            this.MaHD.Size = new System.Drawing.Size(10, 10);
            this.MaHD.TabIndex = 194;
            this.MaHD.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaHD.TextName = "";
            // 
            // txtpass
            // 
            this.txtpass.BackColor = System.Drawing.Color.Transparent;
            this.txtpass.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtpass.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtpass.ForeColors = System.Drawing.Color.Transparent;
            this.txtpass.HintText = null;
            this.txtpass.IsPassword = false;
            this.txtpass.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtpass.LineThickness = 2;
            this.txtpass.Location = new System.Drawing.Point(994, 32);
            this.txtpass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpass.MaxLength = 32767;
            this.txtpass.Name = "txtpass";
            this.txtpass.OnFocusedColor = System.Drawing.Color.Black;
            this.txtpass.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtpass.ReadOnly = false;
            this.txtpass.Size = new System.Drawing.Size(10, 10);
            this.txtpass.TabIndex = 193;
            this.txtpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtpass.TextName = "";
            // 
            // txtuser
            // 
            this.txtuser.BackColor = System.Drawing.Color.Transparent;
            this.txtuser.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtuser.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtuser.ForeColors = System.Drawing.Color.Transparent;
            this.txtuser.HintText = null;
            this.txtuser.IsPassword = false;
            this.txtuser.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtuser.LineThickness = 2;
            this.txtuser.Location = new System.Drawing.Point(994, 23);
            this.txtuser.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtuser.MaxLength = 32767;
            this.txtuser.Name = "txtuser";
            this.txtuser.OnFocusedColor = System.Drawing.Color.Black;
            this.txtuser.OnFocusedTextColor = System.Drawing.Color.Black;
            this.txtuser.ReadOnly = false;
            this.txtuser.Size = new System.Drawing.Size(10, 10);
            this.txtuser.TabIndex = 192;
            this.txtuser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtuser.TextName = "";
            // 
            // MaKH
            // 
            this.MaKH.BackColor = System.Drawing.Color.Transparent;
            this.MaKH.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MaKH.ForeColors = System.Drawing.Color.Transparent;
            this.MaKH.HintText = null;
            this.MaKH.IsPassword = false;
            this.MaKH.LineBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MaKH.LineThickness = 2;
            this.MaKH.Location = new System.Drawing.Point(976, 23);
            this.MaKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaKH.MaxLength = 32767;
            this.MaKH.Name = "MaKH";
            this.MaKH.OnFocusedColor = System.Drawing.Color.Black;
            this.MaKH.OnFocusedTextColor = System.Drawing.Color.Black;
            this.MaKH.ReadOnly = false;
            this.MaKH.Size = new System.Drawing.Size(10, 10);
            this.MaKH.TabIndex = 191;
            this.MaKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.MaKH.TextName = "";
            // 
            // quayve
            // 
            this.quayve.BorderColor = System.Drawing.Color.Black;
            this.quayve.ButtonColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.quayve.FlatAppearance.BorderSize = 0;
            this.quayve.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.quayve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quayve.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quayve.Location = new System.Drawing.Point(12, 12);
            this.quayve.Name = "quayve";
            this.quayve.OnHoverBorderColor = System.Drawing.Color.Black;
            this.quayve.OnHoverButtonColor = System.Drawing.Color.Black;
            this.quayve.OnHoverTextColor = System.Drawing.Color.White;
            this.quayve.Size = new System.Drawing.Size(76, 36);
            this.quayve.TabIndex = 189;
            this.quayve.Text = "<<";
            this.quayve.TextColor = System.Drawing.Color.Black;
            this.quayve.UseVisualStyleBackColor = true;
            this.quayve.Click += new System.EventHandler(this.quayve_Click);
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Location = new System.Drawing.Point(12, 71);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(992, 549);
            this.crystalReportViewer1.TabIndex = 195;
            this.crystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // NV_6_1Taophieudv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1017, 632);
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.MaHD);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtuser);
            this.Controls.Add(this.MaKH);
            this.Controls.Add(this.quayve);
            this.Name = "NV_6_1Taophieudv";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phiếu Dịch Vụ";
            this.Load += new System.EventHandler(this.NV_6_1Taophieudv_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private JMaterialTextbox.JMaterialTextbox MaHD;
        private JMaterialTextbox.JMaterialTextbox txtpass;
        private JMaterialTextbox.JMaterialTextbox txtuser;
        private JMaterialTextbox.JMaterialTextbox MaKH;
        private ePOSOne.btnProduct.Button_WOC quayve;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
    }
}